function T = static_g1_tt(T, y, x, params)
% function T = static_g1_tt(T, y, x, params)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%
% Output:
%   T         [#temp variables by 1]  double   vector of temporary terms
%

assert(length(T) >= 320);

T = dynare_transition.static_resid_tt(T, y, x, params);

T(238) = (-(y(342)*y(357)));
T(239) = getPowerDeriv(y(76)/y(75),T(2),1);
T(240) = getPowerDeriv(y(77)/y(76),T(2),1);
T(241) = getPowerDeriv(y(78)/y(77),T(2),1);
T(242) = getPowerDeriv(y(79)/y(78),T(2),1);
T(243) = getPowerDeriv(y(80)/y(79),T(2),1);
T(244) = getPowerDeriv(y(81)/y(80),T(2),1);
T(245) = getPowerDeriv(y(82)/y(81),T(2),1);
T(246) = getPowerDeriv(y(83)/y(82),T(2),1);
T(247) = getPowerDeriv(y(84)/y(83),T(2),1);
T(248) = getPowerDeriv(y(85)/y(84),T(2),1);
T(249) = getPowerDeriv(y(86)/y(85),T(2),1);
T(250) = getPowerDeriv(y(87)/y(86),T(2),1);
T(251) = getPowerDeriv(y(88)/y(87),T(2),1);
T(252) = getPowerDeriv(y(89)/y(88),T(2),1);
T(253) = getPowerDeriv(y(90)/y(89),T(2),1);
T(254) = getPowerDeriv(y(91)/y(90),T(2),1);
T(255) = getPowerDeriv(y(92)/y(91),T(2),1);
T(256) = getPowerDeriv(y(93)/y(92),T(2),1);
T(257) = getPowerDeriv(y(94)/y(93),T(2),1);
T(258) = getPowerDeriv(y(95)/y(94),T(2),1);
T(259) = getPowerDeriv(y(96)/y(95),T(2),1);
T(260) = getPowerDeriv(y(97)/y(96),T(2),1);
T(261) = getPowerDeriv(y(98)/y(97),T(2),1);
T(262) = getPowerDeriv(y(99)/y(98),T(2),1);
T(263) = getPowerDeriv(y(100)/y(99),T(2),1);
T(264) = getPowerDeriv(y(101)/y(100),T(2),1);
T(265) = getPowerDeriv(y(102)/y(101),T(2),1);
T(266) = getPowerDeriv(y(103)/y(102),T(2),1);
T(267) = getPowerDeriv(y(104)/y(103),T(2),1);
T(268) = getPowerDeriv(y(105)/y(104),T(2),1);
T(269) = getPowerDeriv(y(106)/y(105),T(2),1);
T(270) = getPowerDeriv(y(107)/y(106),T(2),1);
T(271) = getPowerDeriv(y(108)/y(107),T(2),1);
T(272) = getPowerDeriv(y(109)/y(108),T(2),1);
T(273) = getPowerDeriv(y(110)/y(109),T(2),1);
T(274) = getPowerDeriv(y(111)/y(110),T(2),1);
T(275) = getPowerDeriv(y(112)/y(111),T(2),1);
T(276) = getPowerDeriv(y(113)/y(112),T(2),1);
T(277) = getPowerDeriv(y(114)/y(113),T(2),1);
T(278) = getPowerDeriv(y(115)/y(114),T(2),1);
T(279) = getPowerDeriv(y(116)/y(115),T(2),1);
T(280) = getPowerDeriv(y(117)/y(116),T(2),1);
T(281) = getPowerDeriv(y(118)/y(117),T(2),1);
T(282) = getPowerDeriv(y(119)/y(118),T(2),1);
T(283) = getPowerDeriv(y(120)/y(119),T(2),1);
T(284) = getPowerDeriv(y(121)/y(120),T(2),1);
T(285) = getPowerDeriv(y(122)/y(121),T(2),1);
T(286) = getPowerDeriv(y(123)/y(122),T(2),1);
T(287) = getPowerDeriv(y(124)/y(123),T(2),1);
T(288) = getPowerDeriv(y(125)/y(124),T(2),1);
T(289) = getPowerDeriv(y(126)/y(125),T(2),1);
T(290) = getPowerDeriv(y(127)/y(126),T(2),1);
T(291) = getPowerDeriv(y(128)/y(127),T(2),1);
T(292) = getPowerDeriv(y(129)/y(128),T(2),1);
T(293) = getPowerDeriv(y(130)/y(129),T(2),1);
T(294) = getPowerDeriv(y(131)/y(130),T(2),1);
T(295) = getPowerDeriv(y(132)/y(131),T(2),1);
T(296) = getPowerDeriv(y(133)/y(132),T(2),1);
T(297) = getPowerDeriv(y(134)/y(133),T(2),1);
T(298) = getPowerDeriv(y(135)/y(134),T(2),1);
T(299) = getPowerDeriv(y(136)/y(135),T(2),1);
T(300) = getPowerDeriv(y(137)/y(136),T(2),1);
T(301) = getPowerDeriv(y(138)/y(137),T(2),1);
T(302) = getPowerDeriv(y(139)/y(138),T(2),1);
T(303) = getPowerDeriv(y(140)/y(139),T(2),1);
T(304) = getPowerDeriv(y(141)/y(140),T(2),1);
T(305) = getPowerDeriv(y(142)/y(141),T(2),1);
T(306) = getPowerDeriv(y(143)/y(142),T(2),1);
T(307) = getPowerDeriv(y(144)/y(143),T(2),1);
T(308) = getPowerDeriv(y(145)/y(144),T(2),1);
T(309) = getPowerDeriv(y(146)/y(145),T(2),1);
T(310) = getPowerDeriv(y(147)/y(146),T(2),1);
T(311) = getPowerDeriv(y(148)/y(147),T(2),1);
T(312) = (-y(342));
T(313) = y(350)*y(350);
T(314) = (1-params(1))*x(5)*getPowerDeriv(y(350)*x(5),T(227),1);
T(315) = getPowerDeriv(T(228),1/(params(5)-1),1);
T(316) = y(345)*T(314)*T(315);
T(317) = getPowerDeriv(T(228),params(5)/(params(5)-1),1);
T(318) = params(1)*params(52)*getPowerDeriv(params(52)*y(352),T(227),1);
T(319) = y(345)*T(315)*T(318);
T(320) = getPowerDeriv(y(564)*y(589)/params(6),(-params(4)),1);

end
