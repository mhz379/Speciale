function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
% function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double  vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double  vector of endogenous variables in the order stored
%                                                    in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double  matrix of exogenous variables (in declaration order)
%                                                    for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double  vector of steady state values
%   params        [M_.param_nbr by 1]        double  vector of parameter values in declaration order
%   it_           scalar                     double  time period for exogenous variables for which
%                                                    to evaluate the model
%
% Output:
%   T           [#temp variables by 1]       double  vector of temporary terms
%

assert(length(T) >= 465);

T = dynare_transition.dynamic_resid_tt(T, y, x, params, steady_state, it_);

T(383) = (-(y(646)*y(661)));
T(384) = getPowerDeriv(y(896)/y(379),T(2),1);
T(385) = getPowerDeriv(y(897)/y(380),T(2),1);
T(386) = getPowerDeriv(y(898)/y(381),T(2),1);
T(387) = getPowerDeriv(y(899)/y(382),T(2),1);
T(388) = getPowerDeriv(y(900)/y(383),T(2),1);
T(389) = getPowerDeriv(y(901)/y(384),T(2),1);
T(390) = getPowerDeriv(y(902)/y(385),T(2),1);
T(391) = getPowerDeriv(y(903)/y(386),T(2),1);
T(392) = getPowerDeriv(y(904)/y(387),T(2),1);
T(393) = getPowerDeriv(y(905)/y(388),T(2),1);
T(394) = getPowerDeriv(y(906)/y(389),T(2),1);
T(395) = getPowerDeriv(y(907)/y(390),T(2),1);
T(396) = getPowerDeriv(y(908)/y(391),T(2),1);
T(397) = getPowerDeriv(y(909)/y(392),T(2),1);
T(398) = getPowerDeriv(y(910)/y(393),T(2),1);
T(399) = getPowerDeriv(y(911)/y(394),T(2),1);
T(400) = getPowerDeriv(y(912)/y(395),T(2),1);
T(401) = getPowerDeriv(y(913)/y(396),T(2),1);
T(402) = getPowerDeriv(y(914)/y(397),T(2),1);
T(403) = getPowerDeriv(y(915)/y(398),T(2),1);
T(404) = getPowerDeriv(y(916)/y(399),T(2),1);
T(405) = getPowerDeriv(y(917)/y(400),T(2),1);
T(406) = getPowerDeriv(y(918)/y(401),T(2),1);
T(407) = getPowerDeriv(y(919)/y(402),T(2),1);
T(408) = getPowerDeriv(y(920)/y(403),T(2),1);
T(409) = getPowerDeriv(y(921)/y(404),T(2),1);
T(410) = getPowerDeriv(y(922)/y(405),T(2),1);
T(411) = getPowerDeriv(y(923)/y(406),T(2),1);
T(412) = getPowerDeriv(y(924)/y(407),T(2),1);
T(413) = getPowerDeriv(y(925)/y(408),T(2),1);
T(414) = getPowerDeriv(y(926)/y(409),T(2),1);
T(415) = getPowerDeriv(y(927)/y(410),T(2),1);
T(416) = getPowerDeriv(y(928)/y(411),T(2),1);
T(417) = getPowerDeriv(y(929)/y(412),T(2),1);
T(418) = getPowerDeriv(y(930)/y(413),T(2),1);
T(419) = getPowerDeriv(y(931)/y(414),T(2),1);
T(420) = getPowerDeriv(y(932)/y(415),T(2),1);
T(421) = getPowerDeriv(y(933)/y(416),T(2),1);
T(422) = getPowerDeriv(y(934)/y(417),T(2),1);
T(423) = getPowerDeriv(y(935)/y(418),T(2),1);
T(424) = getPowerDeriv(y(936)/y(419),T(2),1);
T(425) = getPowerDeriv(y(937)/y(420),T(2),1);
T(426) = getPowerDeriv(y(938)/y(421),T(2),1);
T(427) = getPowerDeriv(y(939)/y(422),T(2),1);
T(428) = getPowerDeriv(y(940)/y(423),T(2),1);
T(429) = getPowerDeriv(y(941)/y(424),T(2),1);
T(430) = getPowerDeriv(y(942)/y(425),T(2),1);
T(431) = getPowerDeriv(y(943)/y(426),T(2),1);
T(432) = getPowerDeriv(y(944)/y(427),T(2),1);
T(433) = getPowerDeriv(y(945)/y(428),T(2),1);
T(434) = getPowerDeriv(y(946)/y(429),T(2),1);
T(435) = getPowerDeriv(y(947)/y(430),T(2),1);
T(436) = getPowerDeriv(y(948)/y(431),T(2),1);
T(437) = getPowerDeriv(y(949)/y(432),T(2),1);
T(438) = getPowerDeriv(y(950)/y(433),T(2),1);
T(439) = getPowerDeriv(y(951)/y(434),T(2),1);
T(440) = getPowerDeriv(y(952)/y(435),T(2),1);
T(441) = getPowerDeriv(y(953)/y(436),T(2),1);
T(442) = getPowerDeriv(y(954)/y(437),T(2),1);
T(443) = getPowerDeriv(y(955)/y(438),T(2),1);
T(444) = getPowerDeriv(y(956)/y(439),T(2),1);
T(445) = getPowerDeriv(y(957)/y(440),T(2),1);
T(446) = getPowerDeriv(y(958)/y(441),T(2),1);
T(447) = getPowerDeriv(y(959)/y(442),T(2),1);
T(448) = getPowerDeriv(y(960)/y(443),T(2),1);
T(449) = getPowerDeriv(y(961)/y(444),T(2),1);
T(450) = getPowerDeriv(y(962)/y(445),T(2),1);
T(451) = getPowerDeriv(y(963)/y(446),T(2),1);
T(452) = getPowerDeriv(y(964)/y(447),T(2),1);
T(453) = getPowerDeriv(y(965)/y(448),T(2),1);
T(454) = getPowerDeriv(y(966)/y(449),T(2),1);
T(455) = getPowerDeriv(y(967)/y(450),T(2),1);
T(456) = getPowerDeriv(y(968)/y(451),T(2),1);
T(457) = (-y(646));
T(458) = y(654)*y(654);
T(459) = getPowerDeriv(y(654)*x(it_, 5),T(371),1);
T(460) = getPowerDeriv(T(372),1/(params(5)-1),1);
T(461) = getPowerDeriv(T(372),params(5)/(params(5)-1),1);
T(462) = params(1)*params(52)*getPowerDeriv(params(52)*y(656),T(371),1);
T(463) = y(649)*T(460)*T(462);
T(464) = (-T(367));
T(465) = getPowerDeriv(y(277)*y(302)/params(6),(-params(4)),1);

end
