function T = dynamic_g2_tt(T, y, x, params, steady_state, it_)
% function T = dynamic_g2_tt(T, y, x, params, steady_state, it_)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double  vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double  vector of endogenous variables in the order stored
%                                                    in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double  matrix of exogenous variables (in declaration order)
%                                                    for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double  vector of steady state values
%   params        [M_.param_nbr by 1]        double  vector of parameter values in declaration order
%   it_           scalar                     double  time period for exogenous variables for which
%                                                    to evaluate the model
%
% Output:
%   T           [#temp variables by 1]       double  vector of temporary terms
%

assert(length(T) >= 772);

T = dynare_ss_2024_calibr.dynamic_g1_tt(T, y, x, params, steady_state, it_);

T(691) = getPowerDeriv(y(76)/y(75),T(3),2);
T(692) = getPowerDeriv(y(77)/y(76),T(3),2);
T(693) = getPowerDeriv(y(78)/y(77),T(3),2);
T(694) = getPowerDeriv(y(79)/y(78),T(3),2);
T(695) = getPowerDeriv(y(80)/y(79),T(3),2);
T(696) = getPowerDeriv(y(81)/y(80),T(3),2);
T(697) = getPowerDeriv(y(82)/y(81),T(3),2);
T(698) = getPowerDeriv(y(83)/y(82),T(3),2);
T(699) = getPowerDeriv(y(84)/y(83),T(3),2);
T(700) = getPowerDeriv(y(85)/y(84),T(3),2);
T(701) = getPowerDeriv(y(86)/y(85),T(3),2);
T(702) = getPowerDeriv(y(87)/y(86),T(3),2);
T(703) = getPowerDeriv(y(88)/y(87),T(3),2);
T(704) = getPowerDeriv(y(89)/y(88),T(3),2);
T(705) = getPowerDeriv(y(90)/y(89),T(3),2);
T(706) = getPowerDeriv(y(91)/y(90),T(3),2);
T(707) = getPowerDeriv(y(92)/y(91),T(3),2);
T(708) = getPowerDeriv(y(93)/y(92),T(3),2);
T(709) = getPowerDeriv(y(94)/y(93),T(3),2);
T(710) = getPowerDeriv(y(95)/y(94),T(3),2);
T(711) = getPowerDeriv(y(96)/y(95),T(3),2);
T(712) = getPowerDeriv(y(97)/y(96),T(3),2);
T(713) = getPowerDeriv(y(98)/y(97),T(3),2);
T(714) = getPowerDeriv(y(99)/y(98),T(3),2);
T(715) = getPowerDeriv(y(100)/y(99),T(3),2);
T(716) = getPowerDeriv(y(101)/y(100),T(3),2);
T(717) = getPowerDeriv(y(102)/y(101),T(3),2);
T(718) = getPowerDeriv(y(103)/y(102),T(3),2);
T(719) = getPowerDeriv(y(104)/y(103),T(3),2);
T(720) = getPowerDeriv(y(105)/y(104),T(3),2);
T(721) = getPowerDeriv(y(106)/y(105),T(3),2);
T(722) = getPowerDeriv(y(107)/y(106),T(3),2);
T(723) = getPowerDeriv(y(108)/y(107),T(3),2);
T(724) = getPowerDeriv(y(109)/y(108),T(3),2);
T(725) = getPowerDeriv(y(110)/y(109),T(3),2);
T(726) = getPowerDeriv(y(111)/y(110),T(3),2);
T(727) = getPowerDeriv(y(112)/y(111),T(3),2);
T(728) = getPowerDeriv(y(113)/y(112),T(3),2);
T(729) = getPowerDeriv(y(114)/y(113),T(3),2);
T(730) = getPowerDeriv(y(115)/y(114),T(3),2);
T(731) = getPowerDeriv(y(116)/y(115),T(3),2);
T(732) = getPowerDeriv(y(117)/y(116),T(3),2);
T(733) = getPowerDeriv(y(118)/y(117),T(3),2);
T(734) = getPowerDeriv(y(119)/y(118),T(3),2);
T(735) = getPowerDeriv(y(120)/y(119),T(3),2);
T(736) = getPowerDeriv(y(121)/y(120),T(3),2);
T(737) = getPowerDeriv(y(122)/y(121),T(3),2);
T(738) = getPowerDeriv(y(123)/y(122),T(3),2);
T(739) = getPowerDeriv(y(124)/y(123),T(3),2);
T(740) = getPowerDeriv(y(125)/y(124),T(3),2);
T(741) = getPowerDeriv(y(126)/y(125),T(3),2);
T(742) = getPowerDeriv(y(127)/y(126),T(3),2);
T(743) = getPowerDeriv(y(128)/y(127),T(3),2);
T(744) = getPowerDeriv(y(129)/y(128),T(3),2);
T(745) = getPowerDeriv(y(130)/y(129),T(3),2);
T(746) = getPowerDeriv(y(131)/y(130),T(3),2);
T(747) = getPowerDeriv(y(132)/y(131),T(3),2);
T(748) = getPowerDeriv(y(133)/y(132),T(3),2);
T(749) = getPowerDeriv(y(134)/y(133),T(3),2);
T(750) = getPowerDeriv(y(135)/y(134),T(3),2);
T(751) = getPowerDeriv(y(136)/y(135),T(3),2);
T(752) = getPowerDeriv(y(137)/y(136),T(3),2);
T(753) = getPowerDeriv(y(138)/y(137),T(3),2);
T(754) = getPowerDeriv(y(139)/y(138),T(3),2);
T(755) = getPowerDeriv(y(140)/y(139),T(3),2);
T(756) = getPowerDeriv(y(141)/y(140),T(3),2);
T(757) = getPowerDeriv(y(142)/y(141),T(3),2);
T(758) = getPowerDeriv(y(143)/y(142),T(3),2);
T(759) = getPowerDeriv(y(144)/y(143),T(3),2);
T(760) = getPowerDeriv(y(145)/y(144),T(3),2);
T(761) = getPowerDeriv(y(146)/y(145),T(3),2);
T(762) = getPowerDeriv(y(147)/y(146),T(3),2);
T(763) = getPowerDeriv(y(148)/y(147),T(3),2);
T(764) = y(350)+y(350);
T(765) = T(681)*T(681);
T(766) = (1-params(1))*params(281)*params(281)*getPowerDeriv(y(350)*params(281),T(303),2);
T(767) = getPowerDeriv(T(304),1/(params(5)-1),2);
T(768) = y(345)*(T(683)*T(766)+T(682)*T(682)*T(767));
T(769) = params(1)*params(282)*params(282)*getPowerDeriv(params(282)*y(352),T(303),2);
T(770) = y(345)*(T(687)*T(687)*T(767)+T(683)*T(769));
T(771) = getPowerDeriv(T(304),params(5)/(params(5)-1),2);
T(772) = (y(352)*params(2)+y(347)+y(350)+y(344)*y(352))*(y(344)+params(2))+(y(352)*params(2)+y(347)+y(350)+y(344)*y(352))*(y(344)+params(2));

end
