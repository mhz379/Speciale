function T = static_g1_tt(T, y, x, params)
% function T = static_g1_tt(T, y, x, params)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%
% Output:
%   T         [#temp variables by 1]  double   vector of temporary terms
%

assert(length(T) >= 397);

T = dynare_ss_2024.static_resid_tt(T, y, x, params);

T(316) = (-(y(342)*y(361)));
T(317) = getPowerDeriv(y(76)/y(75),T(3),1);
T(318) = getPowerDeriv(y(77)/y(76),T(3),1);
T(319) = getPowerDeriv(y(78)/y(77),T(3),1);
T(320) = getPowerDeriv(y(79)/y(78),T(3),1);
T(321) = getPowerDeriv(y(80)/y(79),T(3),1);
T(322) = getPowerDeriv(y(81)/y(80),T(3),1);
T(323) = getPowerDeriv(y(82)/y(81),T(3),1);
T(324) = getPowerDeriv(y(83)/y(82),T(3),1);
T(325) = getPowerDeriv(y(84)/y(83),T(3),1);
T(326) = getPowerDeriv(y(85)/y(84),T(3),1);
T(327) = getPowerDeriv(y(86)/y(85),T(3),1);
T(328) = getPowerDeriv(y(87)/y(86),T(3),1);
T(329) = getPowerDeriv(y(88)/y(87),T(3),1);
T(330) = getPowerDeriv(y(89)/y(88),T(3),1);
T(331) = getPowerDeriv(y(90)/y(89),T(3),1);
T(332) = getPowerDeriv(y(91)/y(90),T(3),1);
T(333) = getPowerDeriv(y(92)/y(91),T(3),1);
T(334) = getPowerDeriv(y(93)/y(92),T(3),1);
T(335) = getPowerDeriv(y(94)/y(93),T(3),1);
T(336) = getPowerDeriv(y(95)/y(94),T(3),1);
T(337) = getPowerDeriv(y(96)/y(95),T(3),1);
T(338) = getPowerDeriv(y(97)/y(96),T(3),1);
T(339) = getPowerDeriv(y(98)/y(97),T(3),1);
T(340) = getPowerDeriv(y(99)/y(98),T(3),1);
T(341) = getPowerDeriv(y(100)/y(99),T(3),1);
T(342) = getPowerDeriv(y(101)/y(100),T(3),1);
T(343) = getPowerDeriv(y(102)/y(101),T(3),1);
T(344) = getPowerDeriv(y(103)/y(102),T(3),1);
T(345) = getPowerDeriv(y(104)/y(103),T(3),1);
T(346) = getPowerDeriv(y(105)/y(104),T(3),1);
T(347) = getPowerDeriv(y(106)/y(105),T(3),1);
T(348) = getPowerDeriv(y(107)/y(106),T(3),1);
T(349) = getPowerDeriv(y(108)/y(107),T(3),1);
T(350) = getPowerDeriv(y(109)/y(108),T(3),1);
T(351) = getPowerDeriv(y(110)/y(109),T(3),1);
T(352) = getPowerDeriv(y(111)/y(110),T(3),1);
T(353) = getPowerDeriv(y(112)/y(111),T(3),1);
T(354) = getPowerDeriv(y(113)/y(112),T(3),1);
T(355) = getPowerDeriv(y(114)/y(113),T(3),1);
T(356) = getPowerDeriv(y(115)/y(114),T(3),1);
T(357) = getPowerDeriv(y(116)/y(115),T(3),1);
T(358) = getPowerDeriv(y(117)/y(116),T(3),1);
T(359) = getPowerDeriv(y(118)/y(117),T(3),1);
T(360) = getPowerDeriv(y(119)/y(118),T(3),1);
T(361) = getPowerDeriv(y(120)/y(119),T(3),1);
T(362) = getPowerDeriv(y(121)/y(120),T(3),1);
T(363) = getPowerDeriv(y(122)/y(121),T(3),1);
T(364) = getPowerDeriv(y(123)/y(122),T(3),1);
T(365) = getPowerDeriv(y(124)/y(123),T(3),1);
T(366) = getPowerDeriv(y(125)/y(124),T(3),1);
T(367) = getPowerDeriv(y(126)/y(125),T(3),1);
T(368) = getPowerDeriv(y(127)/y(126),T(3),1);
T(369) = getPowerDeriv(y(128)/y(127),T(3),1);
T(370) = getPowerDeriv(y(129)/y(128),T(3),1);
T(371) = getPowerDeriv(y(130)/y(129),T(3),1);
T(372) = getPowerDeriv(y(131)/y(130),T(3),1);
T(373) = getPowerDeriv(y(132)/y(131),T(3),1);
T(374) = getPowerDeriv(y(133)/y(132),T(3),1);
T(375) = getPowerDeriv(y(134)/y(133),T(3),1);
T(376) = getPowerDeriv(y(135)/y(134),T(3),1);
T(377) = getPowerDeriv(y(136)/y(135),T(3),1);
T(378) = getPowerDeriv(y(137)/y(136),T(3),1);
T(379) = getPowerDeriv(y(138)/y(137),T(3),1);
T(380) = getPowerDeriv(y(139)/y(138),T(3),1);
T(381) = getPowerDeriv(y(140)/y(139),T(3),1);
T(382) = getPowerDeriv(y(141)/y(140),T(3),1);
T(383) = getPowerDeriv(y(142)/y(141),T(3),1);
T(384) = getPowerDeriv(y(143)/y(142),T(3),1);
T(385) = getPowerDeriv(y(144)/y(143),T(3),1);
T(386) = getPowerDeriv(y(145)/y(144),T(3),1);
T(387) = getPowerDeriv(y(146)/y(145),T(3),1);
T(388) = getPowerDeriv(y(147)/y(146),T(3),1);
T(389) = getPowerDeriv(y(148)/y(147),T(3),1);
T(390) = (y(347)+y(342)*y(350)+y(344)*y(352)+y(352)*params(3))*(y(347)+y(342)*y(350)+y(344)*y(352)+y(352)*params(3));
T(391) = y(350)*y(350);
T(392) = (1-params(1))*params(281)*getPowerDeriv(y(350)*params(281),T(305),1);
T(393) = getPowerDeriv(T(306),1/(params(5)-1),1);
T(394) = y(345)*T(392)*T(393);
T(395) = getPowerDeriv(T(306),params(5)/(params(5)-1),1);
T(396) = params(1)*params(282)*getPowerDeriv(params(282)*y(352),T(305),1);
T(397) = y(345)*T(393)*T(396);

end
