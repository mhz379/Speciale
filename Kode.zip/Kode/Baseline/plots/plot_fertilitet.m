%Laver plot over fertiliteten i forskellige lande.

% Add the path to the folder containing 'Ny data'

% Specify the full path to the file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\un_fertility_flere lande.xlsx';

% Load the data from the first sheet ("Import") of the Excel file
data = readtable(filename, 'Sheet', 'Import');

% Extract the years and fertility rates for each country
years = data{:, 1}; % First column: years
Canada = data{:, 2};
Kina = data{:, 3};
Frankrig = data{:, 4};
Tyskland = data{:, 5};
Indien = data{:, 6};
Italien = data{:, 7};
Japan = data{:, 8};
UK = data{:, 9};
USA = data{:, 10};
Verden = data{:, 11};
HI = data{:,12}; %Højindkomstlande
% Low fertility series:
Canada_lav = data{:, 13};
Kina_lav = data{:, 14};
Frankrig_lav = data{:, 15};
Tyskland_lav = data{:, 16};
Indien_lav = data{:, 17};
Italien_lav = data{:, 18};
Japan_lav = data{:, 19};
UK_lav = data{:, 20};
USA_lav = data{:, 21};
Verden_lav = data{:, 22};
HI_lav = data{:,23};

% Create the plot
figure;

plot(years, Verden, 'Color', [0 0 0.5], 'LineStyle', '-', 'LineWidth', 1.5); hold on; % Dark blue for Verden
plot(years, USA, 'k-', 'LineWidth', 1.5); % Black for USA
plot(years, Tyskland, 'Color', [0.5 0.5 0.5], 'LineStyle', '-', 'LineWidth', 1.5); % Grey for Tyskland
plot(years, Japan, 'Color', [0.5 0 0], 'LineStyle', '-', 'LineWidth', 1.5); % Dark red for Japan
plot(years, Verden_lav, 'Color', [0 0 0.5], 'LineStyle', '--', 'LineWidth', 1.5); % Dark blue for Verden_lav
plot(years, USA_lav, 'k--', 'LineWidth', 1.5); % Black dashed for USA_lav
plot(years, Tyskland_lav, 'Color', [0.5 0.5 0.5], 'LineStyle', '--', 'LineWidth', 1.5); % Grey dashed for Tyskland_lav
plot(years, Japan_lav, 'Color', [0.5 0 0], 'LineStyle', '--', 'LineWidth', 1.5); % Dark red dashed for Japan_lav

hold off;


% Adding title and labels
title('Fertilitetskvotient (1960-2050)');
%xlabel('År');
ylabel('Børn pr. kvinde','FontSize', 15);

% Adding legend
legend({'Verden','USA', 'Tyskland', 'Japan' }, 'Location', 'Best', 'FontSize', 15);

% Enhancing the plot
set(gca, 'FontSize', 15); % Set font size for the axes
grid off;
xlim([years(11), years(101)]); % Set x-axis limits based on the data

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);

hold off;
% Function to format y-axis ticks with commas
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end

