%Laver plot over gini og formueforholdet

% Load the empirical Gini data from the Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Gini_USA.xlsx';
sheet_name = 'Import';
data_empirical = readtable(filename, 'Sheet', sheet_name);  % Read the empirical data

% Extract the year and empirical Gini coefficients
years_empirical = data_empirical{:, 1};  % Year column
gini_empirical = data_empirical{:, 2};  % Gini coefficient column

% Load Gini coefficient from the alternative simulation (without pensions) in the current folder
load('gini_v2_u.mat', 'Gini_coefficients');  % Load variable from .mat file in current folder
gini_uden_paygo = Gini_coefficients;  % Rename to avoid conflict with main Gini coefficients

% Simulated Gini coefficients
% Preallocate Gini array for each period as before
Gini_coefficients = zeros(T, 1);

% Population of each generation (n{j})
pop_indiv = Simulated_time_series.data(1:T, 1:74); % Use this to calculate weighted averages for each period.

% Loop over each time period to calculate the Gini coefficient for simulated data
for t = 1:T
    a_t = a_indiv_dyn(t, :);  % Wealth for each generation in period t
    N = numel(a_t);  % Number of generations (74)
    
    % Calculate weighted average wealth for period t
    mean_a_t = sum(a_t .* pop_indiv(t, :)) / sum(pop_indiv(t, :));

    % Calculate Gini coefficient for simulated data
    G = 0;
    for i = 1:N
        for j = 1:N
            G = G + abs(a_t(i) - a_t(j)) * pop_indiv(t, i) * pop_indiv(t, j);
        end
    end
    Gini_coefficients(t) = (G / (2 * sum(pop_indiv(t, :))^2 * mean_a_t)) * 100;  % Scale by 100
end


% Scale the empirical Gini by 100
gini_empirical = gini_empirical*100;

% Define the x-axis years from 1970 to 1970 + T - 1
years_simulated = 1970:(1970 + T - 1);

% PLOT 1: Compare two simulated Gini coefficients
figure;
plot(years_simulated, gini_uden_paygo, 'LineWidth', 2, 'Color', [0.5 0 0], 'DisplayName', 'Uden pensioner'); % Dark Red
hold on;
plot(years_simulated, Gini_coefficients, 'LineWidth', 2, 'Color', [0 0 0], 'DisplayName', 'Med pensioner'); % Black
title('Simuleret Gini-koefficient (1970-2120)','FontSize', 15);
%xlabel('År');
ylabel('Gini-koefficient','FontSize', 15);
legend('Location', 'best', 'FontSize', 15);
grid on;
xlim([1970, 2120]);

% Set font size and color for x and y axis tick labels in Plot 1
ax1 = gca;
ax1.XAxis.FontSize = 15;
ax1.YAxis.FontSize = 15;
ax1.YAxis.Color = [0 0 0];  % Set y-axis tick color to black
hold off;

% PLOT 2: Index the Gini series to 100 in 1970 and compare with empirical data

% Limit the series to the period 1970-2022
end_year = 2022;
years_limit_mask = (years_simulated <= end_year);
Gini_simulated_limited = Gini_coefficients(years_limit_mask);
gini_uden_paygo_limited = gini_uden_paygo(years_limit_mask);
years_limited_simulated = years_simulated(years_limit_mask);

% Limit empirical data to 1970-2022
years_limit_empirical = (years_empirical >= 1970 & years_empirical <= end_year);
gini_empirical_limited = gini_empirical(years_limit_empirical);
years_limited_empirical = years_empirical(years_limit_empirical);

% Index both Gini series to 100 in 1970
index_year = 1970;
gini_simulated_indexed = Gini_simulated_limited / Gini_simulated_limited(1) * 100;
gini_uden_paygo_indexed = gini_uden_paygo_limited / gini_uden_paygo_limited(1) * 100;
gini_empirical_indexed = gini_empirical_limited / gini_empirical_limited(1) * 100;

% Plot both indexed Gini series together (1970-2022)
figure;
hold on;
plot(years_limited_simulated, gini_simulated_indexed, 'LineWidth', 2, 'Color', [0 0 0], 'DisplayName', 'Med pensioner'); % Black
plot(years_limited_simulated, gini_uden_paygo_indexed, 'LineWidth', 2, 'Color', [0.5 0 0], 'DisplayName', 'Uden pensioner'); % Dark Red
plot(years_limited_empirical, gini_empirical_indexed, 'LineWidth', 2, 'Color', [0 0 0.5], 'LineStyle', '--', 'DisplayName', 'Data'); % Dark Blue Dashed
title('Formueulighed: model vs. data (Gini-koefficient i 1970=100)','FontSize', 15);
%xlabel('År');
ylabel('Indeks 1970=100','FontSize', 15);
legend('Location', 'best', 'FontSize', 15);
grid on;
xlim([1970, end_year]);

% Set font size for x and y axis tick labels in Plot 2
ax2 = gca;
ax2.XAxis.FontSize = 15;
ax2.YAxis.FontSize = 15;
hold off;

% PLOT 3: Compare the three Gini coefficients for 1970-2022 (not indexed)

% Create a new figure
figure;

% Plot the two simulated Gini coefficients on the left y-axis
yyaxis left
plot(years_limited_simulated, gini_uden_paygo_limited, 'LineWidth', 2, 'Color', [0.5 0 0], 'LineStyle', '-', 'DisplayName', 'Uden pensioner'); % Dark Red
hold on;
plot(years_limited_simulated, Gini_simulated_limited, 'LineWidth', 2, 'Color', [0 0 0], 'LineStyle', '-', 'DisplayName', 'Med pensioner'); % Black
ylabel('Gini (model)', 'FontSize', 15);
ax3 = gca;
ax3.YAxis(1).FontSize = 15;
ax3.YAxis(1).Color = [0 0 0];  % Set left y-axis tick color to black

% Plot the empirical Gini coefficient on the right y-axis, scaled by 100
yyaxis right
plot(years_limited_empirical, gini_empirical_limited, 'LineWidth', 2, 'Color', [0 0 0.5], 'LineStyle', '--', 'DisplayName', 'Data (h. akse)'); % Dark Blue Dashed
ylabel('Gini (data)', 'FontSize', 15);
ax3.YAxis(2).FontSize = 15;
ax3.YAxis(2).Color = [0 0 0];  % Set right y-axis tick color to black

% Title, x-axis label, and legend
title('Formueulighed: model vs. data (1970-2022)', 'FontSize', 15);
%xlabel('År');
legend('Location', 'best', 'FontSize', 15);
grid on;
xlim([1970, end_year]);

% Set font size for x-axis tick labels in Plot 3
ax3.XAxis.FontSize = 15;
ax3.XAxis.Color = [0 0 0];  % Set x-axis tick color to black

hold off;

%PLOT 4: Fordeling mellem pensionister og arbejdere
% Calculate wealth ratio between pensioners and workers for each period
load('wealth_ratio_v2_U.mat', 'wealth_ratio');  % Load variable from .mat file in current folder
wealth_ratio_uden_paygo = wealth_ratio;  % Rename to avoid conflict with main Gini coefficients

wealth_ratio = zeros(T, 1);  % Preallocate array for the ratio

for t = 1:T
    % Wealth and population for pensioners (ages j=43 to j=74)
    wealth_pensioners = sum(a_indiv_dyn(t, 43:74) .* pop_indiv(t, 43:74));
    population_pensioners = sum(pop_indiv(t, 43:74));
    
    % Wealth and population for workers (ages j=1 to j=42)
    wealth_workers = sum(a_indiv_dyn(t, 1:42) .* pop_indiv(t, 1:42));
    population_workers = sum(pop_indiv(t, 1:42));
    
    % Calculate wealth ratio
    wealth_ratio(t) = wealth_pensioners / wealth_workers;
end

% Plot the wealth ratio over time
figure;
plot(years_simulated, wealth_ratio_uden_paygo, 'LineWidth', 2, 'Color', [0.5 0 0], 'LineStyle', '-', 'DisplayName', 'Uden pensioner');
hold on;
plot(years_simulated, wealth_ratio, 'LineWidth', 2, 'Color', [0 0 0], 'LineStyle', '-','DisplayName', 'Med pensioner');
title('Formueforhold mellem pensionister og arbejdere (1970-2100)');
%xlabel('År');
ylabel('Ratio');
legend('Location', 'best', 'FontSize', 15);
grid on;
xlim([1970, 2100]);

% Adjust the y-axis to use commas instead of points for decimals
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply modified tick labels
hold off;

% Optional: Save the plot
% saveas(gcf, 'sammenligning_gini_indekseret.png');
