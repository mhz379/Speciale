%Laver plot over den agg. opsparingskvote og C/N

% Load interest rate (r_dyn should be the saved variable in the workspace)
%load('r_dyn.mat');
r = r_dyn;

%Wages (w)
w =Simulated_time_series.data(1:T,342);

% Agg. Capital (K)
K_dyn = Simulated_time_series.data(1:T, 352);  % Productive capital

%Government Debt
gov_debt_dyn=Simulated_time_series.data(1:T,355);

% Government debt as a fraction of capital
B = gov_debt_dyn .* K_dyn;  % Government debt

% Output (Y)
Y_dyn = Simulated_time_series.data(1:T, 348);  % Output (GDP)

% Total Labor (L)
L_dyn=Simulated_time_series.data(1:T,350);

%Total Population (N)
N_dyn=Simulated_time_series.data(1:T,349);

%Total Consumption (C)
C_dyn=Simulated_time_series.data(1:T,351);

%Total Profit (PI)
PI_dyn=Simulated_time_series.data(1:T,347);

delta = delta_p;

%Pensioner
E = Simulated_time_series.data(1:T,356);

% Load income tax rate from the simulated series
%load('Simulated_time_series.mat');
tau = Simulated_time_series.data(:,346);  % Assuming column 346 is the tax rate

% Define the x-axis years from 1970 to 2169 (corresponding to period 1 to 201)
years = 1970:(1970 + T - 1);

% PLOT 1 - AGG. OPSPARINGSKVOTE

% Total disposable income (Y_dyn - total taxes and depreciation of capital + overførsler)
total_disp_inc = Y_dyn - tau .* L_dyn .* w - taup .* PI_dyn - delta .* K_dyn + E + r .* B;

% Calculating the aggregate savings rate
aggregate_savings_rate = (total_disp_inc - C_dyn) ./ total_disp_inc;

% Plot the aggregate savings rate over time
figure;
hold on;
plot(years, aggregate_savings_rate * 100, 'Color', [0.3 0.3 0.3], 'LineWidth', 2); % Dark grey line
hold off;

% Add labels, title, and legend
%xlabel('År', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);
title('Opsparingskvote (1970-2100)', 'FontSize', 15);
%legend('Location', 'Best', 'FontSize', 15);
grid on;

% Limit the x-axis to 1970-2100
xlim([1970, 2100]);

% Set font size for x- and y-axis tick labels
ax = gca;
ax.XAxis.FontSize = 15;
ax.YAxis.FontSize = 15;

%PLOT 2: C/N, forbrug per indbygger

% Calculate consumption per capita (C/N)
CN = C_dyn ./ N_dyn;

% Index C/N to 1 in 1970
CN_1970 = CN(1);  % Value of C/N in 1970
CN_indexed = CN / CN_1970;  % Index C/N to 1 in 1970

figure;
hold on;
plot(years, CN_indexed, 'Color', [0.3 0.3 0.3], 'LineWidth', 2); % Dark grey line
hold off;

% Add labels, title, and legend
%xlabel('År', 'FontSize', 15);
ylabel('C/N', 'FontSize', 15);
title('Forbrug per indbygger (1970=1)', 'FontSize', 15);
%legend('Location', 'Best', 'FontSize', 15);
grid on;

% Adjust the y-axis to use commas instead of points for decimals
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply modified tick labels


% Limit the x-axis to 1970-2100
xlim([1970, 2100]);

% Set font size for x- and y-axis tick labels
ax = gca;
ax.XAxis.FontSize = 15;
ax.YAxis.FontSize = 15;
