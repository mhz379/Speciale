% Laver plot over udgifterne til Social Security og Medicare
% Indlæser data fra Excel-filen
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Offentligt forbrug.xlsx';  % Path to your Excel file
sheet_name = 'Import2';  % Sheet name where the data is stored
data = readtable(filename, 'Sheet', sheet_name);  % Read the table from the specified sheet

% Ekstraherer datoer, realløn og lønandel
dates = datetime(data{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Assuming dates are in the first column
social_security = data{:, 2}*100;  % Udgifter til social security ift. BNP
medicare = data{:, 3}*100;  % Udgifter til medicare ift. BNP

% PLOT 1: Social security og Medicare i pct. af BNP
figure;
hold on;
plot(dates(4:end), social_security(4:end), 'Color', [0 0 0.5], 'LineWidth', 2, 'DisplayName', 'Social Security'); % Dark blue
plot(dates(4:end), medicare(4:end), 'Color', [0.5 0 0], 'LineWidth', 2, 'DisplayName', 'Medicare'); % Dark red
title('Udgifter til Social Security og Medicare i pct. af BNP (1970-2023)', 'FontSize', 15);
%xlabel('Year', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);
legend('Location', 'best', 'FontSize', 15);
grid on;

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);
hold off;

% Calculate the ratio of Medicare to Social Security
ratio = medicare ./ social_security;

% Extend ratio with assumed values for 2024 and 2025
ratio_extended = [ratio; ratio(end); ratio(end)];

% Calculate the 5-year moving average
ratio_moving_avg = movmean(ratio_extended, 5);

% PLOT 2: Ratio of Medicare to Social Security spending with 5-year moving average
figure;
plot(dates(4:end), ratio_moving_avg(4:end-2), 'Color', [0.3 0.3 0.3], 'LineWidth', 2); % Dark grey
title('Forhold mellem udgifter til Medicare og Social Security (1970-2023)', 'FontSize', 15);
%xlabel('Year', 'FontSize', 15);
ylabel('Ratio', 'FontSize', 15);
grid on;

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);
hold off;

% Function to format y-axis ticks with commas
function format_y_ticks(ax)
    yticks = get(ax, 'YTick');  % Get current y-tick values
    yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
    set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end
