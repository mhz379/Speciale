% Laver plot over forbrugsgæld (CDY) og sammeligner med data.

% 1. Indlæser data fra Excel-filen
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Forbrugsgæld.xlsx';  % Path to your Excel file
sheet_name = 'Import';  % Sheet name where the data is stored
data = readtable(filename, 'Sheet', sheet_name);  % Read the table from the specified sheet

% Ekstraherer datoer og empirisk CDY (consumer debt as share of GDP)
years = datetime(data{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Convert dates to datetime format
cdy_emp = data{:, 2};  % Consumer debt as a share of GDP (empirical)

a = a_indiv_dyn;          % Adjust the variable name to match the loaded one
n = pop_indiv_dyn;
% Output (Y)
Y_dyn = Simulated_time_series.data(1:T, 348);  % Output (GDP)

% Transponer n
n = n';
% Initialize a vector to store total consumer debt for each period
total_consumer_debt = zeros(1, T);

% Loop over all periods to calculate aggregate consumer debt
for t = 1:T
    personal_debt = 0;  % Reset personal debt for each period
    for j = 1:J
        if a(t, j) < 0  % Check if the asset value is negative
            % Aggregate the debt weighted by population size
            personal_debt = personal_debt + a(t, j) * n(j, t);
        end
    end
    % Store the absolute total consumer debt for this period
    total_consumer_debt(t) = -personal_debt;  % Debt is negative, so take the absolute value
end

% Calculate Consumer Debt to GDP Ratio (CDY) over time
Y_dyn_trans = Y_dyn';

CDY = total_consumer_debt ./ Y_dyn_trans;
CDY_100 = CDY * 100;  % Multiply by 100 to get percentage

% Ensure the length of simulated data matches the empirical data range (1970-2023)
CDY_100 = CDY_100(1:length(years));

% Plot the Consumer Debt to GDP Ratio (CDY) over time with empirical data
figure;
hold on;
plot(years, CDY_100, 'k-', 'LineWidth', 2, 'DisplayName', 'Model'); % Black line for simulated data
plot(years, cdy_emp * 100, 'Color', [0.5 0 0], 'LineStyle', '--', 'LineWidth', 2, 'DisplayName', 'Data'); % Dark red dashed line for empirical data
%xlabel('Year', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);
title('Forbrugsgæld ift. BNP (1970-2023)', 'FontSize', 15);
legend('Location', 'Best', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes
grid on;
hold off;
