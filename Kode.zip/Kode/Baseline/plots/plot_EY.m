%Laver plot over arv ift. BNP i modellen.

% Set the path to the main folder and the subfolder where the script is located

% Total Income (Y)
Y = Simulated_time_series.data(1:T,348);

E = Simulated_time_series.data(1:T,356);

%B = Simulated_time_series.data(1:T,s);

% Calculate the ratio E/Y for all periods
EY = E ./ Y; %Skal være 5% i 2023.

% Plot the ratio of E/Y over time and save it in the 'plots' folder
figure;
plot(1:T, EY, '-');
title('Ratio of Social Security Spending (E) to Output (Y) Over Time');
xlabel('Period');
ylabel('E/Y Ratio');
grid on;

% Step to display E/Y in year 54 (which corresponds to 2023)
year_2023_index = 54;  % Year 2023 corresponds to index 54
EY_2023 = EY(year_2023_index);

% Display the E/Y value for the year 2023
fprintf('The value of E/Y in year 54 (2023) is: %.4f\n', EY_2023);

% Save the plot as an image in the 'plots' folder
%saveas(gcf, fullfile(main_folder, subfolder, 'EY_ratio_plot.png'));
