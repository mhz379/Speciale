%Laver plot over væksten i BNP per capita og sammenligner med data

T = 201;  % Number of periods

% -------------------------------------------------------------------------
% Load necessary data

filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\BNP_per_capita.xlsx'; 
sheet_name = 'import';  % Sheet name where the data is stored
opts = detectImportOptions(filename, 'Sheet', sheet_name);
opts.VariableNamingRule = 'preserve';  % Preserve the original column headers

data = readtable(filename, opts);  % Read the table from the specified sheet

% Extract year and GDP per capita from the empirical data (54 periods from 1970)
years_empirical = data{1:54, 1};  % Assuming the first column contains the years
gdp_per_capita_empirical = data{1:54, 2};  % Assuming GDP per capita is in the second column

% GDP (Y)
Y_dyn = Simulated_time_series.data(1:T, 348);

% Population (N)
N_dyn = Simulated_time_series.data(1:T, 349);  % Assuming population is column 349

% -------------------------------------------------------------------------
% Calculate GDP growth rates (Y_growth)
Y_growth = (Y_dyn(2:end) - Y_dyn(1:end-1)) ./ Y_dyn(1:end-1);

% Calculate GDP per capita (Y/N) and its growth rates (Y_per_capita_growth)
Y_per_capita = Y_dyn ./ N_dyn;
Y_per_capita_growth = (Y_per_capita(2:end) - Y_per_capita(1:end-1)) ./ Y_per_capita(1:end-1) * 100;  % Express as percentage

% -------------------------------------------------------------------------
% PLOT 1. Plot GDP Growth
figure;
plot(2:T, Y_growth, 'b-', 'LineWidth', 1.5);
xlabel('Time (Periods)');
ylabel('GDP Growth Rate');
title('GDP Growth Rate Over Time');
xlim([1, 100]);
grid on;

% -------------------------------------------------------------------------
% PLOT 2. Plot GDP per Capita Growth with Year Labels
figure;
plot(1971:T+1969, Y_per_capita_growth, 'r--', 'LineWidth', 1.5);  % Adjust x-axis to start from 1971
xlabel('Year');
ylabel('GDP per Capita Growth Rate');
title('GDP per Capita Growth Rate Over Time');
xlim([1970, 2069]);  % Limit x-axis from 1970 to 2069 (assuming T=201)
grid on;

% -------------------------------------------------------------------------
% PLOT 3. Plot over vækst i BNP per capita i modellen vs. data.

% Calculate empirical GDP per capita growth rates
gdp_per_capita_growth_empirical = diff(gdp_per_capita_empirical) ./ gdp_per_capita_empirical(1:end-1) * 100;

% Use Hodrick-Prescott filter to smooth the empirical growth rates (lambda = 100)
lambda = 10;
[gdp_per_capita_growth_smoothed, ~] = hpfilter(gdp_per_capita_growth_empirical, lambda);

% Generate the plot
figure;
hold on;

% Plot simulated GDP per capita growth rates
plot(1971:2023, Y_per_capita_growth(1:53), 'k', 'LineWidth', 1.5, 'DisplayName', 'Model');

% Plot empirical GDP per capita growth rates
plot(1971:2023, gdp_per_capita_growth_empirical, 'r--', 'LineWidth', 1.5, 'DisplayName', 'Empirical Data');

% Plot smoothed empirical GDP per capita growth rates
plot(1971:2023, gdp_per_capita_growth_smoothed, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Smoothed Empirical Data');

% Set plot labels and title
xlabel('Year');
ylabel('GDP per Capita Growth Rate');
title('Comparison of GDP per Capita Growth: Model vs. Empirical Data (with Smoothing)');
legend('Location', 'Best');
xlim([1970, 2023]);  % Limit x-axis from 1970 to 2023
grid on;
hold off;

% -------------------------------------------------------------------------
% Calculate the correlation coefficient between the smoothed empirical growth rate and the model growth rate

% Ensure both series are the same length
gdp_per_capita_growth_simulated = Y_per_capita_growth(1:53);

% Calculate the correlation coefficient
correlation_coefficient = corrcoef(gdp_per_capita_growth_smoothed, gdp_per_capita_growth_simulated);

% Display the correlation coefficient
disp('Correlation Coefficient between Smoothed Empirical Growth Rate and Model Growth Rate:');
disp(correlation_coefficient(1,2));  % Display only the correlation value (off-diagonal element)
