% Plot til at sammenligne renter under hhv. konstant dødelighed, fertilitet
% og produktivitetsvækst.
clear all

% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('r_v2.mat');
r_v2 = baseline.r_dyn*100;

const_gdebt = load('r_v2.5_b.mat');
r_v2_const_b = const_gdebt.r_dyn*100;

const_theta = load('r_v2.5_theta.mat');
r_v2_const_theta = const_theta.r_dyn*100;

const_D = load('r_v2.5_D.mat');
r_v2_const_D = const_D.r_dyn*100;

% Define the years for the plot (1970 to 2030)
years = 1970:2030;

% Create the plot
figure;
hold on;

% Plot each interest rate scenario with specified line width
plot(years, r_v2(1:61), 'k-', 'LineWidth', 2, 'DisplayName', 'Baseline');
plot(years, r_v2_const_b(1:61), 'b--', 'LineWidth', 2, 'DisplayName', 'Konstant statsgæld');
plot(years, r_v2_const_theta(1:61), 'r-.', 'LineWidth', 2, 'DisplayName', 'Konstant theta');
plot(years, r_v2_const_D(1:61), 'g:', 'LineWidth', 2, 'DisplayName', 'Konstant D');

% Add legend, labels, and title with specified font size
legend('Location', 'best', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct. p.a.', 'FontSize', 15);
%title('Udvikling i r* under forskellige scenarier (1970-2030)', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes
grid on;

% Adjust the y-axis to use commas instead of points for decimals
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply modified tick labels

hold off;
