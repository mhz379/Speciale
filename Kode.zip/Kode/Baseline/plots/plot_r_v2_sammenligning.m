% Plot til at sammenligne renter under hhv. konstant dødelighed, fertilitet
% og produktivitetsvækst.
clear all

% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('r_v2.mat');
r_v2 = baseline.r_dyn*100;

const_mortality = load('r_v2_2.mat');
r_v2_2 = const_mortality.r_dyn*100;

const_fertility = load('r_v2_3.mat');
r_v2_3 = const_fertility.r_dyn*100;

const_productivity = load('r_v2_4.mat');
r_v2_4 = const_productivity.r_dyn*100;

% Define the years for the plot (1970 to 2030)
years = 1970:2030;

% Create the plot
figure;
hold on;

% Plot each interest rate scenario with specified line width
plot(years, r_v2(1:61), 'k-', 'LineWidth', 2, 'DisplayName', 'Baseline');
plot(years, r_v2_2(1:61), 'r-.', 'LineWidth', 2, 'DisplayName', 'Konstant dødelighed');
plot(years, r_v2_3(1:61), 'b--', 'LineWidth', 2, 'DisplayName', 'Konstant fertilitet');
plot(years, r_v2_4(1:61), 'g:', 'LineWidth', 2, 'DisplayName', 'Konstant produktivitetsvækst');

% Add legend, labels, and title with specified font size
legend('Location', 'best', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct. p.a.', 'FontSize', 15);
%title('Udvikling i r* under forskellige scenarier (1970-2030)', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes
grid on;

% Adjust the y-axis to use commas instead of points for decimals
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply modified tick labels

hold off;
