% Plot til at sammenligne renter GP scenarier 1-3 
clear all

% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('r_v2.mat'); %Baseline
r_v2 = baseline.r_dyn*100;

s1 = load('r_v2_s1.mat'); %Scenarie 1
r_v2_s1 = s1.r_dyn*100;

s2 = load('r_v2_s2.mat'); %Scenarie 2
r_v2_s2 = s2.r_dyn*100;

s3 = load('r_v2_s3.mat'); %Scenarie 3
r_v2_s3 = s3.r_dyn*100;

% Define the years for the plot (1970 to 2030)
years = 1970:2100;

% Create the plot
figure;
hold on;

% Plot each interest rate scenario with specified line width
plot(years, r_v2(1:131), 'k-', 'LineWidth', 2, 'DisplayName', 'Baseline');
plot(years, r_v2_s1(1:131), 'Color', [0 0 0.5], 'LineStyle', '-.', 'LineWidth', 2, 'DisplayName', 'Scenarie 1');  % Dark blue
plot(years, r_v2_s2(1:131), 'Color', [0.6 0 0], 'LineStyle', '--', 'LineWidth', 2, 'DisplayName', 'Scenarie 2');  % Dark red
plot(years, r_v2_s3(1:131), 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 2, 'DisplayName', 'Scenarie 3');  % Grey


% Add legend, labels, and title with specified font size
legend('Location', 'best', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct. p.a.', 'FontSize', 15);
xlim([1970 2100]);
%title('Udvikling i r* under forskellige scenarier (1970-2100)', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes
grid on;

% Adjust the y-axis to use commas instead of points for decimals
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply modified tick labels

hold off;
