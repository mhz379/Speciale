% Laver plot over r*, dvs. HLW udglattet med et HP-filter
clear all

% Load the data from the Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\HLW_data.xlsx';
data = readtable(filename);

% Extract the date and the series
dates = data{:, 1}; % Assuming dates are in the first column
USA = data{:, 2};   % Assuming USA data is in the second column
Canada = data{:, 3}; % Assuming Canada data is in the third column
Eurozonen = data{:, 4}; % Assuming Eurozone data is in the fourth column

% Convert dates from text to datetime format if necessary
dates = datetime(dates, 'InputFormat', 'dd-MM-yyyy');

% Plotting the three series with specified colors
figure;
plot(dates, Canada, 'Color', [0.5 0 0], 'LineWidth', 2); hold on; % Dark red for Canada
plot(dates, USA, 'k-', 'LineWidth', 2); % Black for USA
plot(dates, Eurozonen, 'Color', [0.5 0.5 0.5], 'LineWidth', 2); % Grey for Eurozone
hold off;

% Adding title and labels
title('Udvikling i r* (1970-2024)', 'FontSize', 15);
%xlabel('Dato', 'FontSize', 15);
ylabel('Pct. p.a.', 'FontSize', 15);

% Adding legend
legend('Canada', 'USA', 'Eurozonen', 'Location', 'Best', 'FontSize', 15);

% Enhancing the plot
grid off;
xlim([dates(1), dates(end)]); % Set x-axis limits based on the data
xtickformat('yyyy'); % Display years on the x-axis for datetime values

% Set font size for x and y-axis tick labels
set(gca, 'FontSize', 15);
