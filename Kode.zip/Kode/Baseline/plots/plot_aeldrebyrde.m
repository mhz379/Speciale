% Laver plot over ældrebyrden beregnet af FN. Bruges i indledningen.
clear all

% Load the data from the first sheet ("Import") of the Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Ældrebyrde USA 1950-2100.xlsx';
data = readtable(filename, 'Sheet', 'Import');

% Extract the date and the two age dependency ratios
years = data{:, 1}; % First column: years
age_dependency_medium = data{:, 2}; % Second column: medium fertility
age_dependency_low = data{:, 3};    % Third column: low fertility (starts after 2023)

% Create the plot
figure;
plot(years, age_dependency_medium, 'black-', 'LineWidth', 2); hold on;
plot(years, age_dependency_low, 'black--', 'LineWidth', 2);
hold off;

% Adding title and labels
title('65+ ift. 20-64-årige (1960-2100)', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);

% Adding a single legend for each fertility scenario
legend('Mellem fertilitet', 'Lav fertilitet', 'Location', 'Best', 'FontSize', 15);

% Enhancing the plot
grid off;
xlim([years(11), years(end)]); % Set x-axis limits based on the data

% Set font size for x and y-axis tick labels
set(gca, 'FontSize', 15);
