% Laver plot over forbrugskurven i 2024 for forskellige værdier af rho

% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('forbrug_2024_rho95.mat');
f1 = baseline.data_year_55_indexed; % Baseline, hvor rho=0,95.

v2_6 = load('forbrug_2024_rho65.mat');
f2 = v2_6.data_year_55_indexed; % Baseline_v2.6, hvor rho=0,65.

v2_7 = load('forbrug_2024_rho125.mat');
f3 = v2_7.data_year_55_indexed; % Baseline_v2.7, hvor rho=1,25.

% Step 2: Define the age groups for c_indiv_dyn (map 1 to 74 as 25 to 98)
age_groups_dyn = linspace(25, 98, 74);  % Age mapping from 25 to 98

% Start the plot and use 'hold on' to plot multiple series
figure;
hold on;

% Plot the indexed series from c_indiv_dyn (74 generations)

plot(age_groups_dyn, f3, '-.', 'Color', [0.6 0 0], 'LineWidth', 2, 'DisplayName', '\rho=1,25');  % Dark red [0.6 0 0] 
plot(age_groups_dyn, f1, 'Color', [0 0 0], 'LineWidth', 2, 'DisplayName', '\rho=0,95 (baseline)');  % Black [0 0 0]
plot(age_groups_dyn, f2, '--', 'Color', [0 0 0.6], 'LineWidth', 2, 'DisplayName', '\rho=0,65'); % Dark blue [0 0 0.6] 

% Add the indexed BLS consumption profile to the plot (only until age 74)
%plot(age_groups_dyn(age_groups_dyn <= 74), rebased_BLS(age_groups_dyn <= 74), '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 2, 'DisplayName', 'Data (BLS)');  % Grey for BLS data

% Customize the plot for c_indiv_dyn
title('Betydning af \rho: Forbrug efter alder i udvalgte år, indeks 25=1', 'FontSize', 15);
xlabel('Alder', 'FontSize', 15);
ylabel('Indeks 25=1', 'FontSize', 15);
xlim([25, 99]);

% Display the legend and set its font size to 15
legend('show', 'FontSize', 15);

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);
grid on;
hold off;


% Function to format y-axis ticks with commas
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end
