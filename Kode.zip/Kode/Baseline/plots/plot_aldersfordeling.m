%Laver plot over aldersfordelingen (befolkningspyramiden) i modellen.

% Assuming pop_indiv_dyn is the 200x74 matrix where:
% 200 rows are years and 74 columns are generations

% Step 1: Extract the data for year 100, 199, and 200
data_year_1 = pop_indiv_dyn(1, :);  % Data for year 1970
data_year_56 = pop_indiv_dyn(56, :);  % Data for year 2060
data_year_91 = pop_indiv_dyn(91, :);  % Data for year 2060
data_year_101 = pop_indiv_dyn(101, :);  % Data for year 2070
data_year_200 = pop_indiv_dyn(200, :);  % Data for year 2169
data_year_201 = pop_indiv_dyn(201, :);  % Data for year 2170

% Step 2: Create separate horizontal bar plots

% Plot for year 1
figure;
barh(data_year_1);  % Use barh for horizontal bars
title('Age Distribution for Year 1');
ylabel('Generation');  % The generations will now be on the y-axis
xlabel('Population');
yticks(1:74);  % Label the generations from 1 to 74 on the y-axis
grid on;

% Plot for year 56 (2024)
figure;
barh(data_year_56);  % Use barh for horizontal bars
title('Age Distribution for Year 2024');
ylabel('Generation');
xlabel('Population');
yticks(1:74);
grid on;


% Plot for year 91
figure;
barh(data_year_91);  % Use barh for horizontal bars
title('Age Distribution for Year 2060');
ylabel('Generation');
xlabel('Population');
yticks(1:74);
grid on;

% Plot for year 101
figure;
barh(data_year_101);  % Use barh for horizontal bars
title('Age Distribution for Year 2070');
ylabel('Generation');  % The generations will now be on the y-axis
xlabel('Population');
yticks(1:74);  % Label the generations from 1 to 74 on the y-axis
grid on;


% Plot for year 200
figure;
barh(data_year_200);  % Use barh for horizontal bars
title('Age Distribution for Year 2169');
ylabel('Generation');
xlabel('Population');
yticks(1:74);
grid on;

% Plot for year 201
figure;
barh(data_year_201);  % Use barh for horizontal bars
title('Age Distribution for Year 2170');
ylabel('Generation');
xlabel('Population');
yticks(1:74);
grid on;

% Step 3: Replace decimal points with commas and save as Excel file
% Convert the numeric matrix to a cell array of strings with European format

% Step 3: Prepare data for saving to Excel with European number formatting

% Create a year column from 1 to 200
year_column = (1:200)';

% Concatenate the year column with the population data
pop_indiv_dyn_with_year = [year_column, pop_indiv_dyn];

% Convert numeric matrix to a cell array with European formatting
pop_indiv_dyn_str = cell(size(pop_indiv_dyn_with_year));  % Initialize cell array
for i = 1:size(pop_indiv_dyn_with_year, 1)
    for j = 1:size(pop_indiv_dyn_with_year, 2)
        % Convert numeric value to string and replace '.' with ','
        pop_indiv_dyn_str{i, j} = strrep(num2str(pop_indiv_dyn_with_year(i, j), '%.6f'), '.', ',');
    end
end

% Create the header row (1 to 74) plus the 'Year' header
header = [{'Year'}, arrayfun(@num2str, 1:74, 'UniformOutput', false)];

% Combine header with data
pop_indiv_dyn_final = [header; pop_indiv_dyn_str];

% Step 4: Save the matrix with European formatting to an Excel file
filename = 'pop_indiv_dyn.xlsx';
xlswrite(filename, pop_indiv_dyn_final);

% Notify the user
disp(['Matrix pop_indiv_dyn has been saved as an Excel file with European formatting: ' filename]);

% Step 4: Calculate the median age for each year
median_age = zeros(200, 1);  % Initialize a vector to store the median ages

for year = 1:200
    % Get the population distribution for the current year
    population_distribution = pop_indiv_dyn(year, :);
    
    % Round the population distribution to ensure integer values
    population_distribution = round(population_distribution);
    
    % Ensure there are no negative values in the population distribution
    population_distribution(population_distribution < 0) = 0;
    
    % Create an array of ages corresponding to the generations
    generations = 1:74;
    
    % Find the median age based on the population distribution
    % Repeat each generation by its population count to calculate the true median
    age_values = repelem(generations, population_distribution);
    
    if ~isempty(age_values)
        median_age(year) = median(age_values);
    else
        median_age(year) = NaN; % Handle empty years if necessary
    end
end

% Shift all median ages by adding 25 (since age 1 is defined as age 25)
median_age = median_age + 25;

% Step 5: Plot the median age over time without markers. VIRKER IKKE
figure;
%plot(1:200, median_age, '-');  % '-' for a simple curve without markers
title('Median Age of Population Over Time');
xlabel('Year');
ylabel('Median Age');
grid on;
