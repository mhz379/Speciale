% Compare interest rates: Model with PayGo, without PayGo, and HLW

clear all %Hvis du har kørt andre plots inden, så husk at rense workspace.

% Define path to HLW data and r_uden.mat file
data_folder = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\';
hlw_filename = fullfile(data_folder, 'HLW_data.xlsx');

addpath('D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Baseline_v2\plots');
r_uden_filename = 'r_v2_U.mat';  %henter renten fra simulation uden paygo. Husk at opdatere den.

%PLOT 1 - Sammenligning 1970-2024
% Load HLW data from Excel file
data = readtable(hlw_filename);

% Load interest rate without PayGo from .mat file
data_no_paygo = load(r_uden_filename);
r_uden = data_no_paygo.r_dyn;

%Hent renten med paygo (baseline)
r_med_filename = 'r_v2.mat';
data_med_paygo = load(r_med_filename);
r_med = data_med_paygo.r_dyn;

% Use the 'r_dyn' variable from the workspace (model with PayGo)
%r_dyn_1 = r_dyn(1:54)*100; % Trim and scale to match period 1970-2023. Omdøb til r_dyn_1, da r_dyn ellers ændres i workspace.

% Trim 'r_uden' to match the same period (1970-2024)
r_uden_1 = r_uden(1:55)*100; % Til plot 1

% Trim 'r_uden' to match the same period (1970-2024)
r_med_1 = r_med(1:55)*100; % Til plot 1

% Extract and prepare HLW data
dates = data{:, 1}; % Assuming dates are in the first column
USA = data{:, 2};   % Assuming USA data is in the second column

% Convert dates to datetime format
dates = datetime(dates, 'InputFormat', 'dd-MM-yyyy');

% Annualize HLW data (average per year)
years = year(dates);
unique_years = unique(years);
USA_annual = zeros(length(unique_years), 1);

for i = 1:length(unique_years)
    USA_annual(i) = mean(USA(years == unique_years(i)));
end

% Trim HLW data to match the period (1970-2024)
end_year = 2024;
start_year = end_year - length(r_med_1) + 1;
years_trimmed = unique_years(unique_years >= start_year & unique_years <= end_year);
USA_trimmed = USA_annual(unique_years >= start_year & unique_years <= end_year);

% Ensure the lengths match
if length(USA_trimmed) ~= length(r_med_1)
    error('Length of USA_trimmed (%d) and r_med_1 (%d) do not match.', length(USA_trimmed), length(r_med_1));
end

% Plot HLW data, r_med_1 (with PayGo), and r_uden_1 (without PayGo)
figure;
hold on;

% Plot HLW interest rates (dashed dark blue)
plot(years_trimmed, USA_trimmed, '--', 'Color', [0 0 0.6], 'LineWidth', 2, 'DisplayName', 'HLW');

% Plot r_dyn (with PayGo, dark grey)
plot(years_trimmed, r_med_1, '-', 'Color', 'k', 'LineWidth', 2, 'DisplayName', 'Model med pensioner');

% Plot r_dyn_uden (without PayGo, dark red dashed)
plot(years_trimmed, r_uden_1, '-', 'Color', [0.5 0 0], 'LineWidth', 2, 'DisplayName', 'Model uden pensioner');

% Title, labels, and legend
title('r*: HLW vs. simulation (1970-2024)','FontSize', 15);
%xlabel('Year');
ylabel('Pct. p.a.', 'FontSize', 15);
legend('Location', 'Best', 'FontSize', 15);
% Set font size for x and y tick labels
set(gca, 'FontSize', 15); % Change 12 to your preferred size
% Use European formatting for numbers (commas instead of decimal points)
yt = yticks;  % Henter de aktuelle ticks på y-aksen
yticklabels(strrep(cellstr(num2str(yt', '%.1f')), '.', ','));  % Erstatter punktum med komma og viser to decimaler

% Enhance the plot
grid on;
xlim([years_trimmed(1), years_trimmed(end)]); % Set x-axis limits

hold off;

% Calculate the percentage-point change in each interest rate from 1970 to
% 2024
change_r_with_paygo = r_med_1(end) - r_med_1(1);        % Model with PayGo
change_r_without_paygo = r_uden_1(end) - r_uden_1(1);  % Model without PayGo
change_HLW = USA_trimmed(end) - USA_trimmed(1);             % HLW data

% Display the results
fprintf('Percentage-point change from 1970 to 2024:\n');
fprintf('Model with PayGo: %.2f%%\n', change_r_with_paygo);
fprintf('Model without PayGo: %.2f%%\n', change_r_without_paygo);
fprintf('HLW data: %.2f%%\n', change_HLW);

% Display the interest rates in 2024 using the correct indexing
fprintf('Interest rates in 2024:\n');
fprintf('Model with PayGo: %.2f%%\n', r_med_1(55));           % r_dyn_with_paygo
fprintf('Model without PayGo: %.2f%%\n', r_uden_1(55));     % r_dyn_without_paygo
fprintf('HLW data: %.2f%%\n', USA_trimmed(55));               % HLW data in 2024


% PLOT 2 - Comparison of simulated interest rates with and without PayGo (1970-2100)

% Extend the interest rates series to 1970-2100
years_extended = 1970:2100;  % Extended time period
r_med_extended = r_med(1:length(years_extended)) * 100;   % Adjust if length needs to be trimmed or extended
r_uden_extended = r_uden(1:length(years_extended)) * 100;

% Plot only the simulated interest rates for the extended period
figure;
hold on;

% Plot r_med with PayGo (solid black line)
plot(years_extended, r_med_extended, '-', 'Color', 'k', 'LineWidth', 2, 'DisplayName', 'Med pensioner');

% Plot r_uden without PayGo (solid dark red line)
plot(years_extended, r_uden_extended, '-', 'Color', [0.5 0 0], 'LineWidth', 2, 'DisplayName', 'Uden pensioner');

% Title, labels, and legend
title('r*: med og uden pensioner (1970-2100)','FontSize', 15);
%xlabel('Year');
ylabel('Pct. p.a.');
legend('Location', 'Best', 'FontSize', 15);
set(gca, 'FontSize', 15); % Change 12 to your preferred size
% European formatting for numbers (commas instead of decimal points)
yt = yticks;  % Retrieve current y-ticks
yticklabels(strrep(cellstr(num2str(yt', '%.1f')), '.', ','));  % Replace period with comma and display two decimals

% Enhance the plot
grid on;
xlim([years_extended(1), years_extended(end)]); % Set x-axis limits for 1970-2100

hold off;

