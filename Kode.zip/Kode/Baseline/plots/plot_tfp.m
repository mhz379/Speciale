% Laver plot over produktivitetsvæksten

% Indlæser data fra Excel-filen
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\jr_tfp_ny';
data = readtable(filename);

% Ekstraherer årstal og produktivitetsdata fra kolonne 2 og 3
year = data{:, 1};     % Kolonne A indeholder år
fernald = data{:, 2};  % Kolonne B indeholder Fernald produktivitetsvækst
trend = data{:, 3};    % Kolonne C indeholder den udglattede produktivitetsvækst (lambda=10).

% Opretter en figur for produktivitetsvæksten
figure;
hold on;  % For at plotte flere serier på samme figur

% Plot af Fernald produktivitetsvækst (mørkerød, med gennemsigtighed)
plot(year, fernald, '-', 'Color', [0.5, 0, 0, 0.5], 'LineWidth', 2, 'DisplayName', 'Data');  % Alpha-værdi tilføjet

% Plot af trend produktivitetsvækst (sort, solid)
plot(year, trend, '-', 'Color', [0, 0, 0], 'LineWidth', 2, 'DisplayName', 'Model');

% Tilpasning af figuren med font størrelse 15
%title('Produktivitetsvækst', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct. p.a.', 'FontSize', 15);
legend('show', 'FontSize', 15);
xlim([year(1), year(54)]); % Set x-axis limits based on the data
set(gca, 'FontSize', 15);  % Set font size for axis ticks
grid on;
hold off;
