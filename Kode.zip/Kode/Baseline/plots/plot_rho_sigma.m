% Plot til at sammenligne renter under forskellige værdier af rho og sigma.
clear all

% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('r_v2.mat');
r_v2 = baseline.r_dyn*100; %Baseline, hvor rho=0,95 og sigma=0,6.

rho065 = load('r_v2.6.mat');
r_v2_6 = rho065.r_dyn*100; %rho = 0,65

rho125 = load('r_v2.7.mat');
r_v2_7 = rho125.r_dyn*100; %rho = 1,25

sigma099 = load('r_v2.8.mat');
r_v2_8 = sigma099.r_dyn*100; %sigma = 0,99

sigma120 = load('r_v2.9.mat');
r_v2_9 = sigma120.r_dyn*100; %sigma = 1,20


% Define the years for the plot (1970 to 2170)
years = 1970:2170;

% Ensure the length of 'years' matches the data vectors
years = years(1:131);

% Limit each data vector to the years 1970-2100 (first 131 elements)
r_v2 = r_v2(1:131);
r_v2_6 = r_v2_6(1:131);
r_v2_7 = r_v2_7(1:131);
r_v2_8 = r_v2_8(1:131);
r_v2_9 = r_v2_9(1:131);

% Create the plot
figure;
hold on;

% PLOT 1: rho
% Plot each interest rate scenario with specified line width
plot(years, r_v2_7, 'Color', [0.5 0 0], 'LineStyle', '-.', 'LineWidth', 2, 'DisplayName', '\rho=1,25'); % Dark red dash-dot line
plot(years, r_v2, 'k-', 'LineWidth', 2, 'DisplayName', '\rho=0,95 (baseline)'); % Black line
plot(years, r_v2_6, 'b--', 'LineWidth', 2, 'DisplayName', '\rho=0,65');         % Blue dashed line

% Add legend, labels, and title with specified font size
legend('Location', 'best', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct. p.a.', 'FontSize', 15);
title('r* under forskellige værdier af \rho (1970-2100)', 'FontSize', 15);

% Limit x-axis to 1970–2100
xlim([1970 2100]);

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));

% Apply initial formatting
format_y_ticks(gca);

grid on;
hold off;


% PLOT 2: sigma
figure;
hold on;
% Plot each interest rate scenario with specified line width
plot(years, r_v2_9, 'Color', [0.5 0 0], 'LineStyle', '-.', 'LineWidth', 2, 'DisplayName', '\sigma=1,20'); % Dark red dash-dot line
plot(years, r_v2_8, 'b--', 'LineWidth', 2, 'DisplayName', '\sigma=0,99');         % Blue dashed line
plot(years, r_v2, 'k-', 'LineWidth', 2, 'DisplayName', '\sigma=0,60 (baseline)'); % Black line

% Add legend, labels, and title with specified font size
legend('Location', 'best', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct. p.a.', 'FontSize', 15);
title('r* under forskellige værdier af \sigma (1970-2100)', 'FontSize', 15);

% Limit x-axis to 1970–2100
xlim([1970 2100]);

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));

% Apply initial formatting
format_y_ticks(gca);

grid on;
hold off;

% Function to format y-axis ticks with commas
function format_y_ticks(ax)
    yticks = get(ax, 'YTick');  % Get current y-tick values
    yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
    set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end

