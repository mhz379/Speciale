%Laver plot over renten i modellen med og uden paygo.

% Define the folder path for the data files (relative to the script)
data_folder = fullfile('..', 'Dynare_99_re');  % Go up one folder and into Dynare_99_re

% Define the filenames for the .mat files. De skal gemmes manuelt, så sørg
% for, de er opdaterede.
filename1 = fullfile(data_folder, 'r_dyn_30_09.mat');  % d = 0 (without PayGo)
filename2 = fullfile(data_folder, 'r_dyn_30_09E.mat'); % d = 0.25 (with PayGo)

% Load the .mat files (assume the variable inside is r_dyn for both)
data_no_paygo = load(filename1);  % Load the data for d = 0
data_with_paygo = load(filename2); % Load the data for d = 0.25

% Access the actual data inside the .mat structure (adjust the variable name if needed)
r_no_paygo = data_no_paygo.r_dyn; 
r_with_paygo = data_with_paygo.r_dyn;

% Define the years (1970 to 2169)
years = 1970:2169;

% Plot the two time series on the same plot
figure;
hold on;
plot(years, r_no_paygo, 'LineWidth', 2, 'DisplayName', 'Uden PAYGO (d = 0)');
plot(years, r_with_paygo, 'LineWidth', 2, 'DisplayName', 'MED PAYGO (d = 0.25)');

% Customize the plot
title('Renten (Med og uden PayGo)');
%label('Year');
ylabel('Pct-');
legend('Location', 'Best');
grid on;

% Set the x-axis limits
xlim([1970, 2169]);

hold off;
