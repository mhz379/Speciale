% Laver plot over budgetunderskud og statsgælden i andre lande
clear all;

% Indlæser data fra Excel-filen
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\WEO_2024.xlsx';  % Path to your Excel file
sheet_name_1 = 'Import_1';  % Budgetunderskud
sheet_name_2 = 'Import_2';  % Statsgæld

% Load deficit data (net budget deficit)
data_1 = readtable(filename, 'Sheet', sheet_name_1);  

% Load government debt data (gross as % of GDP)
data_2 = readtable(filename, 'Sheet', sheet_name_2);  

% Extract years and country data (exclude Japan)
years = data_1{:, 1};  % Extract years from the first column
countries = {'Frankrig', 'Tyskland', 'UK', 'USA', 'Italien'};  % Exclude Japan

% Extract deficit and debt data (exclude Japan)
deficit_data = data_1{:, 2:6};  % Columns for Frankrig, Tyskland, UK, USA, Italien
debt_data = data_2{:, 2:6};  % Columns for Frankrig, Tyskland, UK, USA, Italien


% PLOT 1: Budget deficit
figure;
hold on;

% Plot each country's deficit
plot(years, deficit_data(:, 1), '--', 'LineWidth', 2, 'Color', [0.5 0.5 0.5], 'DisplayName', 'Frankrig'); % Grey dashed
plot(years, deficit_data(:, 5), '-.', 'LineWidth', 2, 'Color', [0 0.5 0], 'DisplayName', 'Italien'); % Green
plot(years, deficit_data(:, 2), 'Linestyle', '--', 'LineWidth', 2, 'Color', [0.0 0.0 0.5], 'DisplayName', 'Tyskland'); % Dark blue dashed
plot(years, deficit_data(:, 3), '-', 'LineWidth', 2, 'Color', [0.3 0.6 1], 'DisplayName', 'UK'); % Light blue line
plot(years, deficit_data(:, 4), 'k', 'LineWidth', 2, 'DisplayName', 'USA');



% Add labels, legend, and title
ylabel('Pct.', 'FontSize', 15);
title('Budgetunderskud i pct. af BNP (2005-2029)', 'FontSize', 15);
legend('Location', 'best', 'FontSize', 15);
grid on;

% Adjust tick label font size
set(gca, 'FontSize', 15);

hold off;

% PLOT 2: Government debt
figure;
hold on;

% Plot each country's debt
plot(years, debt_data(:, 1), '--', 'LineWidth', 2, 'Color', [0.5 0.5 0.5], 'DisplayName', 'Frankrig'); % Grey dashed
plot(years, debt_data(:, 5), '-.', 'LineWidth', 2, 'Color', [0 0.5 0], 'DisplayName', 'Italien'); % Green
plot(years, debt_data(:, 2), 'Linestyle', '--', 'LineWidth', 2, 'Color', [0.0 0.0 0.5], 'DisplayName', 'Tyskland'); % Dark blue dashed
plot(years, debt_data(:, 3), '-', 'LineWidth', 2, 'Color', [0.3 0.6 1], 'DisplayName', 'UK'); % Light blue
plot(years, debt_data(:, 4), 'k', 'LineWidth', 2, 'DisplayName', 'USA');

% Add labels, legend, and title
ylabel('Pct.', 'FontSize', 15);
title('Statsgæld i pct. af BNP (2005-2029)', 'FontSize', 15);
legend('Location', 'best', 'FontSize', 15);
grid on;

% Adjust tick label font size
set(gca, 'FontSize', 15);

hold off;
