% Kode til at interpolere data for individuelt forbrug og indkomst fra BLS.

% Consumption and income data from BLS 2023 (10-year intervals)
age_intervals = [30, 40, 50, 60, 70, 80];  % Midpoints of each age group
consumption_intervals = [71.51, 91.15, 97.01, 83.43, 65.03, 52.69];  % Consumption in 10-year intervals
income_intervals = [96.51, 126.47, 137.6, 117.91, 72.19, 53.44]; % Income before taxes in 10-year intervals

% Define the age range for interpolation (from 25 to 98)
age_full = 25:98;  % Every age from 25 to 98

% Interpolate the consumption values for ages 25 to 75 (before the flat region)
consumption_full = interp1([age_intervals(1:end-1), 75], [consumption_intervals(1:end-1), consumption_intervals(end)], age_full(age_full <= 75), 'pchip');

% After age 75, consumption is flat at 52.69
consumption_full(age_full > 75) = 52.69;

% Now we ensure the averages match the original data for each age group (consumption)
age_groups = [25, 35, 45, 55, 65, 75];
original_means_consumption = consumption_intervals;

% Calculate the average consumption in each age group from the interpolated data
for i = 1:length(age_groups)-1
    age_range = age_full >= age_groups(i) & age_full < age_groups(i+1);
    avg_consumption = mean(consumption_full(age_range));
    
    % Adjust the interpolated data to ensure the average equals the original value
    adjustment_factor = original_means_consumption(i) / avg_consumption;
    consumption_full(age_range) = consumption_full(age_range) * adjustment_factor;
end

% Interpolate the income values in a similar way (for ages 25 to 75, before the flat region)
income_full = interp1([age_intervals(1:end-1), 75], [income_intervals(1:end-1), income_intervals(end)], age_full(age_full <= 75), 'pchip'); % Include age 75 in interpolation

% After age 75, income is flat at 53.44 (from the income_intervals data)
income_full(age_full > 75) = 53.44;

% Now we ensure the averages match the original data for each age group (income)
original_means_income = income_intervals;  % Original means from income_intervals

for i = 1:length(age_groups)-1
    age_range = age_full >= age_groups(i) & age_full < age_groups(i+1);
    avg_income = mean(income_full(age_range));
    
    % Adjust the interpolated data to ensure the average equals the original value
    adjustment_factor = original_means_income(i) / avg_income;
    income_full(age_range) = income_full(age_range) * adjustment_factor;
end

% Plot the interpolated consumption and income profiles together
figure;
hold on;
plot(age_full, consumption_full, '-o', 'LineWidth', 2, 'DisplayName', 'Consumption');
plot(age_full, income_full, '-x', 'LineWidth', 2, 'DisplayName', 'Income');
title('Interpolated Consumption and Income Profiles by Age (US 2023)');
xlabel('Age');
ylabel('Value');
legend show;
grid on;
hold off;

% Save the interpolated data (optional)
%save('BLS_data.mat', 'consumption_full', 'income_full'); %Husk at gemme
