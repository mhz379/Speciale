%Plot til at IY under hhv. konstant dødelighed, fertilitet
%og produktivitetsvækst.


% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('IY_v2.mat'); %baseline
IY_baseline = baseline.I_Y*100;

v2_2 = load('IY_v2.2.mat'); %konstant dødelighed
IY_2 = v2_2.I_Y*100;

v2_3 = load('IY_v2.3.mat'); %konstant fertilitet
IY_3 = v2_3.I_Y*100;

v2_4 = load('IY_v2.4.mat'); %konstant produktivitet
IY_4 = v2_4.I_Y*100;

% Define the years for the plot (1970 to 2030)
years = 1970:2030;

% Create the plot
figure;
hold on;

% Plot each interest rate scenario with specified colors and line styles
plot(years, IY_baseline(1:61), 'k-', 'LineWidth', 2, 'DisplayName', 'Baseline'); % Solid black for Baseline
plot(years, IY_2(1:61), 'r-.', 'LineWidth', 2, 'DisplayName', 'Konstant dødelighed'); % dødelighed
plot(years, IY_3(1:61), 'b--', 'LineWidth', 2, 'DisplayName', 'Konstant fertilitet'); % fertilitet
plot(years, IY_4(1:61), 'g:', 'LineWidth', 2, 'DisplayName', 'Konstant produktivitetsvækst'); % produktivitet

% Add legend, labels, and title
legend('Location', 'best', 'FontSize', 15);
%xlabel('År');
ylabel('Pct.','FontSize',15);
xlim([1970 2030]);
title('I/Y: Isolering af drivkræfter (1970-2030)','FontSize',15);
grid on;

% Set font size for x-axis and y-axis tick labels
set(gca, 'FontSize', 15);