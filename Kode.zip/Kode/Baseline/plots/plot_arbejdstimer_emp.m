% Laver plot over det gns. årlige antal arbejdstimer per arbejder i USA

%PLOT 1: Opsparingskvote i udvalgte OECD-lande
% Load savings rate data from the Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Arbejdstimer_OECD.xlsx';  % Path to your Excel file
sheet_name = 'Import';  % Sheet name where the data is stored
data = readtable(filename, 'Sheet', sheet_name);  % Read the table from the specified sheet

% Extract data columns
dates = datetime(data{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Convert the first column to datetime
timer = data{:, 2};  % Arbejdstimer i USA

% Plot
figure;
hold on;
plot(dates, timer, 'LineWidth', 2, 'Color', [0.3 0.3 0.3]); % Dark grey line
hold off;

% Add labels, title, and legend
%xlabel('År', 'FontSize', 15);
ylabel('Timer', 'FontSize', 15);
title('Gns. årlig antal arbejdstimer i USA (1970-2023)', 'FontSize', 15);
%legend('Location', 'best', 'FontSize', 15);
grid on;

% Set font size for x- and y-axis tick labels
ax = gca;
ax.XAxis.FontSize = 15;
ax.YAxis.FontSize = 15;

% Optional: Limit x-axis range
xlim([datetime(1970, 1, 1) datetime(2023, 1, 1)]);