% Laver plot over den empiriske realrente i USA sammen med HLW
clear all

% Load the data from the first sheet ("Import") of the Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Realrenten i USA.xlsx';
data = readtable(filename, 'Sheet', 'Import', 'VariableNamingRule', 'preserve');

% Extract the date and the two interest rate series
months = data{:, 1}; % First column: dato
TenY = data{:, 2} * 100; % 10-årige renter, multiplied by 100
TwoY = data{:, 3} * 100; % 2-årige renter, multiplied by 100
OneY = data{:, 4} * 100; % 1-årige renter, multiplied by 100
HLW = data{:,5} * 100;   % Neutrale rente fra HLW. Kvartalsdata with NaNs for non-quarterly data.

% Interpolating HLW series to fill NaNs smoothly
hlw_not_nan = ~isnan(HLW);
hlw_x = find(hlw_not_nan);  % Indices of non-NaN values
hlw_y = HLW(hlw_not_nan);  % The non-NaN values
hlw_interpolated = interp1(hlw_x, hlw_y, (1:length(HLW))', 'pchip');

% Create the plot
figure;
plot(months, TenY, 'k-', 'LineWidth', 2); hold on; % Black solid for 10-årige, multiplied by 100
plot(months, OneY, 'Color', [0.5 0 0], 'LineStyle', '--', 'LineWidth', 2); % Dark red dashed for 1-årige, multiplied by 100
plot(months, hlw_interpolated, 'Color', [0 0 0.5], 'LineStyle', '-.', 'LineWidth', 2); % Dark blue dash-dot for HLW

% Adding title and labels
title('Realrenter i USA (1982-2024)', 'FontSize', 15);
%xlabel('Dato', 'FontSize', 15);
ylabel('Pct. p.a.', 'FontSize', 15);

% Adding a single legend for each interest rate
legend('10-årig, ex ante', '1-årig, ex ante', 'Neutrale rente (HLW)', 'Location', 'Best', 'FontSize', 15);

% Enhancing the plot
grid off;
xlim([months(1), months(end)]); % Set x-axis limits based on the data

% Set font size for x and y-axis tick labels
set(gca, 'FontSize', 15);
