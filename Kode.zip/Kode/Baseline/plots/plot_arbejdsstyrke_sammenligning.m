%Laver plot over vækstraten i arbejdsstyrken i USA

% Load empirical labor force data from Excel
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Labor force.xlsx';  % Path to your Excel file
sheet_name = 'Import';  % Sheet name where the data is stored
data = readtable(filename, 'Sheet', sheet_name);  % Read the table from the specified sheet

% Extract dates and labor force growth rate data
dates = datetime(data{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Dates in the first column
ls_emp = data{:, 3};  % Årlig vækstrate (ift. kvartal året før)

% Apply HP-filter with lambda=100
[ls_emp_hp,~] = hpfilter(ls_emp, 1600);  % Smoothed growth rate

% Truncate dates and raw data to match the HP-filtered series length
if length(ls_emp_hp) < length(ls_emp)
    dates = dates(1:length(ls_emp_hp));
    ls_emp = ls_emp(1:length(ls_emp_hp));
end

% Plot raw and HP-filtered empirical series
figure;
hold on;

% Plot raw empirical series
plot(dates, ls_emp*100, '-', 'Color', [0.5, 0, 0, 0.5], 'LineWidth', 2, 'DisplayName', 'Data');  % Alpha value added

% Plot HP-filtered empirical series
plot(dates, ls_emp_hp*100, 'Color', [0 0 0.5], 'LineWidth', 2, 'DisplayName', 'Udglattet');

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);

% Add labels, title, and legend
ylabel('Pct.', 'FontSize', 15);  % Annual growth rate
%xlabel('Dato', 'FontSize', 15);  % Add x-axis label with font size 15
%title('Årlig vækstrate i arbejdsstyrken (1970K1-2024K3)', 'FontSize', 15);
xlim([dates(1), dates(end)]);  % Automatically set x-axis to cover all dates

% Update legend and grid with font size 15
legend('Location', 'best', 'FontSize', 15);


% Update tick labels with font size 15
set(gca, 'FontSize', 15);


grid on;
hold off;

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);
grid on;
hold off;
% Function to format y-axis ticks with commas
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end

