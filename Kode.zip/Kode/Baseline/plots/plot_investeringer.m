% Laver plot over investeringerne i modellen

T = 201;
delta = 0.1;  % Depreciation rate

% Total Kapital (K)
K_dyn = Simulated_time_series.data(1:T, 352);

% Total Income (Y)
Y_dyn = Simulated_time_series.data(1:T, 348);

% Total Consumption (C)
C_dyn = Simulated_time_series.data(1:T, 351);

% Rental rate (rk)
rk = Simulated_time_series.data(1:T, 343);

% Price (theta)
theta = Simulated_time_series.data(1:T, 403);
price = (theta - 1) ./ theta;  % Assuming price is calculated this way

% Investments (I)
I = K_dyn(2:T) - (1 - delta) * K_dyn(1:T-1);  % Calculate investments from t=1 to t=T-1

% I in period 201 (steady state value):
I_201 = ss_2024(356);  % Given steady state value of investment in period 201 (row 356)

% Append the steady state value for period 200 to the investments array
I = [I; I_201];

% Define the x-axis years from 1970 to 2170 (consistent with T = 201 periods)
years = 1970:(1970 + T - 1);

% MPK (Marginal Product of Capital) calculation
mpk = rk ./ price;  % Adjust rental rate with price

% Calculate MPK * K (for dynamic efficiency check)
MPK_K = mpk .* K_dyn;

% Indexing Investments and MPK*K to Investments in 1970
I_1970 = I(1);  % Investment value in 1970
I_1 = I / I_1970;  % Index Investments to 1 in 1970
MPK_K = MPK_K / I_1970;  % Index MPK*K to Investments in 1970

% PLOT 1: Investments and MPK*K indexed to 1970 Investments
figure;
hold on;
plot(years, I_1, 'LineWidth', 2, 'Color', [0 0 0], 'DisplayName', 'I'); % Black
plot(years, MPK_K, '--', 'LineWidth', 2, 'Color', [0.5 0 0], 'DisplayName', 'MPK \times K'); % Dark Red, Dashed
title('Bruttoinvesteringer (I) vs. MPK \times K (1970-2100)', 'FontSize', 15);
ylabel('I(1970) = 1', 'FontSize', 15);
legend('show', 'FontSize', 15);
grid on;
xlim([1970, 2100]);

ax1 = gca;
ax1.XAxis.FontSize = 15;
ax1.YAxis.FontSize = 15;

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);

hold off;



xlim([1970, 2100]);
hold off;

% Calculate investment-to-output ratio (I/Y)
I_Y = I ./ Y_dyn;

% Calculate investment-to-consumption ratio (I/C)
I_C = I ./ C_dyn;

% Calculate consumption-to-output ratio (C/Y)
C_Y = C_dyn ./ Y_dyn;

% PLOT 2: Investment-to-Output Ratio (I/Y)
figure;
plot(years, I_Y * 100, 'LineWidth', 2, 'Color', [0.3 0.3 0.3]); % Dark Grey
title('Investeringskvote (I/Y) (1970-2100)', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);
grid on;
ax2 = gca;
ax2.XAxis.FontSize = 15;
ax2.YAxis.FontSize = 15;
xlim([1970, 2100]);

% PLOT 4: Consumption-to-Output Ratio (C/Y)
figure;
plot(years, C_Y * 100, 'LineWidth', 2, 'Color', [0.3 0.3 0.3]); % Dark Grey
title('Forbrugskvote (1970-2100)', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);
grid on;
ax4 = gca;
ax4.XAxis.FontSize = 15;
ax4.YAxis.FontSize = 15;
xlim([1970, 2100]);

% Function to format y-axis ticks with commas
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end

