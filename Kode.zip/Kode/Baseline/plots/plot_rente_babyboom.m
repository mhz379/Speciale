% Plot til at sammenligne renter med og uden babyboomet.
clear all

% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('r_v2.mat');
r_v2 = baseline.r_dyn * 100;

boom = load('r_v2_boom.mat'); % Interest rate only with baby boom as the exogenous variation
r_boom = boom.r_dyn * 100;

noboom = load('r_v2.5_noboom2.mat'); % Without baby boom, but with other exogenous variation
r_noboom = noboom.r_dyn * 100;

% Define the years for the plot (1970 to 2030)
years = 1970:2030;

% Calculate the change in percentage points from 1970 for each series
r_boom_change = r_boom(1:61) - r_boom(1);    % Change in r_boom from 1970 level
r_noboom_change = r_noboom(1:61) - r_noboom(1);    % Change in r_noboom from 1970 level
r_v2_change = r_v2(1:61) - r_v2(1);          % Change in r_v2 from 1970 level

% PLOT 1: Only r_boom from 1970
figure;
plot(years, r_boom(1:61), '-', 'LineWidth', 2, 'Color', [0.3 0.3 0.3], 'DisplayName', 'Boom'); % Dark grey dashed
ylabel('Pct. p.a.', 'FontSize', 15);
title('Babyboomets effekt på renten (1970-2030)', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes
%legend('Location', 'best', 'FontSize', 15);
grid on;
% Format y-axis tick labels to use commas instead of points
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels);

% PLOT 2: Both r_v2 and r_noboom changes from 1970
figure;
hold on;
plot(years, r_v2_change, 'k-', 'LineWidth', 2, 'DisplayName', 'Baseline'); % Black line
plot(years, r_noboom_change, 'b--', 'LineWidth', 2, 'DisplayName', 'Uden babyboom'); % Dark blue dashed
ylabel('Pct.-point', 'FontSize', 15);
title('Ændring i renten siden 1970', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes
legend('Location', 'best', 'FontSize', 15);
grid on;
% Format y-axis tick labels to use commas instead of points
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels);
hold off;
