%Plot til at sammenligne renten forskellige hc-profiler.
clear all
% Plot til at sammenligne renter under hhv. konstant dødelighed, fertilitet
% og produktivitetsvækst.

% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('r_v2.mat'); %baseline
r_v2 = baseline.r_dyn*100;

hc1 = load('r_v2_hc1.mat'); %hc konstant på 1. Fra baseline_v2.10.
r_v2_hc1 = hc1.r_dyn*100;

hc2 = load('r_v2_hc2.mat'); %hc konstant efter j=32 (55 år). Fra baseline_v2.11.
r_v2_hc2 = hc2.r_dyn*100;



% Define the years for the plot (1970 to 2030)
years = 1970:2100;


% Create the plot
figure;
hold on;

% Plot each interest rate scenario with specified colors and line styles
plot(years, r_v2(1:131), 'k-', 'LineWidth', 2, 'DisplayName', 'Baseline');           % Solid black for Baseline
plot(years, r_v2_hc1(1:131), 'color', [0.6 0 0], 'Linestyle', '--' ,'LineWidth', 2, 'DisplayName', 'Konstant hc'); % red dashed
plot(years, r_v2_hc2(1:131), 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 2, 'DisplayName', 'Høj hc'); % Grey dotted

% Add legend, labels, and title
legend('Location', 'best', 'FontSize', 15);
%xlabel('År');
ylabel('Pct. p.a.','FontSize',15);
xlim([1970 2100]);
title('r*: forskellige humankapitalprofiler (1970-2100)','FontSize',15);
grid on;

% Set font size for x-axis and y-axis tick labels
set(gca, 'FontSize', 15);

% Set up a listener to dynamically format the y-axis tick labels with commas on resize
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));

% Initial call to format y-axis tick labels
format_y_ticks(gca);

hold off;

% Function to format y-axis ticks with commas
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end
