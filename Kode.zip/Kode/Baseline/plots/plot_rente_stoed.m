%Plot til at sammenligne renter under hhv. konstant dødelighed, fertilitet
%og produktivitetsvækst.

% Plot til at sammenligne renter under hhv. konstant dødelighed, fertilitet
% og produktivitetsvækst.

% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('r_v2.mat'); %baseline
r_v2 = baseline.r_dyn*100;

theta = load('r_v2_theta.mat'); %stød til theta
r_v2_theta = theta.r_dyn*100;

b200 = load('r_v2_b200.mat'); %stød til statsgælden
r_v2_b200 = b200.r_dyn*100;

m2 = load('r_v2_m2.mat'); %stød til off. forbrug. Brug m2 og ikke m1.
r_v2_m2 = m2.r_dyn*100;

d1 = load('r_v2_d1.mat'); %stød til kompensationsgraden.
r_v2_d1 = d1.r_dyn*100;

% Define the years for the plot (1970 to 2030)
years = 1970:2100;


% Create the plot
figure;
hold on;

% Plot each interest rate scenario with specified colors and line styles
plot(years, r_v2(1:131), 'k-', 'LineWidth', 2, 'DisplayName', 'Baseline');                  % Solid black for Baseline
plot(years, r_v2_b200(1:131), 'r--', 'LineWidth', 2, 'DisplayName', 'Stød: Statsgæld (b)'); % red dashed for Statsgæld
plot(years, r_v2_d1(1:131), 'Color', [0.5 0.5 0.5], 'LineStyle', ':', 'LineWidth', 2, 'DisplayName', 'Stød: Kompensationsgrad (d)'); % Grey dotted for Kompensationsgrad
plot(years, r_v2_theta(1:131), 'b--', 'LineWidth', 2, 'DisplayName', 'Stød: Konkurrence (\theta)');    % Blue dashed for Theta
plot(years, r_v2_m2(1:131), 'g:', 'LineWidth', 2, 'DisplayName', 'Stød: Off. forbrug (g)'); % Green dotted for Off. forbrug

% Add legend, labels, and title
legend('Location', 'best', 'FontSize', 15);
%xlabel('År');
ylabel('Pct. p.a.','FontSize',15);
xlim([1970 2100]);
%title('r* under forskellige stød (1970-2100)','FontSize',15);
grid on;

% Set font size for x-axis and y-axis tick labels
set(gca, 'FontSize', 15);

% Set up a listener to dynamically format the y-axis tick labels with commas on resize
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));

% Initial call to format y-axis tick labels
format_y_ticks(gca);

hold off;

% Function to format y-axis ticks with commas
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end
