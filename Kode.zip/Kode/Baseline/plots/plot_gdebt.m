%Laver plover over statsgælden (empirisk)
clear all 

% Load data from Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\jr_gdebt_ny.xlsx';
sheet_name = 'Samlet gæld';
data = readtable(filename, 'Sheet', sheet_name);

% Extract years and government debt data
years = data{:, 1};  % Year data in the first column
gov_debt_share = data{:, 4}*100;  % Government debt as a share of GDP in the fourth column (GFDEGDQ188S)

% Plot settings
figure;
plot(years, gov_debt_share, 'LineWidth', 2, 'Color', [0.3, 0.3, 0.3]);
title('Statsgæld ift. BNP (1970-2023)', 'FontSize', 15);
%xlabel('Year', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes
grid on;

% Limit x-axis to the range from the first year to 2024
xlim([min(years), 2023]);

% PLOT 2: Off. forbrug og udgifter som andel af BNP.

% Load data from Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Offentligt forbrug.xlsx';
sheet_name = 'Import';
data = readtable(filename, 'Sheet', sheet_name);

% Extract the date and variable columns
dates = datetime(data{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Convert first column to datetime
g = data{:, 2};  % Off. forbrug som andel af BNP (uden overførsler og investeringer)
GE = data{:,3}; %Samlede off. udgifter som andel af BNP

% Define the average line value
avg_g = 0.1554;

% Plot the series and the average line
figure;
hold on;
plot(dates, GE*100, 'LineWidth', 2, 'Color', [0.5 0 0], 'DisplayName', 'Udgifter'); % Dark red line
plot(dates, g*100, 'LineWidth', 2, 'Color', [0 0 0], 'DisplayName', 'Forbrug'); % Black line
% yline(avg_g, '--', 'LineWidth', 2, 'Color', [0.7 0.2 0.2], 'DisplayName', 'Gennemsnit (0.1554)'); % Dark red dashed line (optional)


% Add labels, title, and legend
%xlabel('År', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);
title('Off. forbrug og udgifter ift. BNP (1970-2023)', 'FontSize', 15);
legend('Location', 'best', 'FontSize', 15);
grid on;

% Set font size for x- and y-axis tick labels
ax = gca;
ax.XAxis.FontSize = 15;
ax.YAxis.FontSize = 15;

hold off;
