%Laver plots over husholdningernes opsparing, forbrug og gæld

% Get the parent directory (upper folder) from the current folder where the script is located
currentFolder = fileparts(mfilename('fullpath'));  % Get the path to the "plots" subfolder
parentFolder = fileparts(currentFolder);  % Get the path to the upper folder (Baseline_v1)

% Define paths to the necessary data files in the upper folder
exoMatrixPath = fullfile(parentFolder, 'data', 'exo_matrix_start100.xlsx');
hcPath = fullfile(parentFolder, 'data', 'data_hc.xlsx');

% Load individual assets (a_indiv_dyn should be the saved variable in the workspace)
%load('a_indiv_dyn.mat');  % Assuming you saved the variable in a MAT file
a = a_indiv_dyn;          % Adjust the variable name to match the loaded one

% Load individual consumption
%load('c_indiv_dyn.mat');
c = c_indiv_dyn;

% Load exogenous matrix for survival probabilities with full dimensions (74x201)
exo_matrix = readmatrix(exoMatrixPath);
sv = exo_matrix(1:201, 1:74);  % Adjusted to load the full matrix with 201 rows and 74 columns

% Load interest rate (r_dyn should be the saved variable in the workspace)
%load('r_dyn.mat');
r = r_dyn;

% Agg. Capital (K)
K_dyn = Simulated_time_series.data(1:T, 352);  % Productive capital

%Government Debt
gov_debt_dyn=Simulated_time_series.data(1:T,355);


% Output (Y)
Y_dyn = Simulated_time_series.data(1:T, 348);  % Output (GDP)

% Total Labor (L)
L_dyn=Simulated_time_series.data(1:T,350);

%Total Consumption (C)
C_dyn=Simulated_time_series.data(1:T,351);

%Total Profit (PI)
PI_dyn=Simulated_time_series.data(1:T,347);

delta = delta_p;

%Pensioner
E = Simulated_time_series.data(1:T,356);

% Load bequests received (q should be defined similarly in the workspace)
%load('br_indiv_dyn.mat');
q = br_indiv_dyn;

% Load individual profits (profit_indiv_dyn)
%load('profit_indiv_dyn.mat');
pi = profit_indiv_dyn;

% Tax rate on profits (constant)
taup = taup_p; 

% Load income tax rate from the simulated series
%load('Simulated_time_series.mat');
tau = Simulated_time_series.data(:,346);  % Assuming column 346 is the tax rate

% Load wage income from the simulated series
w = Simulated_time_series.data(:,342);  % Assuming column 342 is the wage

% Pensions are based on the wage, tax rate, and pension compensation ratio
d_bar = d_bar_p;  % Pension compensation ratio after taxes
dw = d_bar * (1 - tau) .* w;  % Pension income

% Load human capital data
hc = readmatrix(hcPath);

n = pop_indiv_dyn;

% Initialize savings (opsparing) and income (indkomst)
% Loop through all individuals to calculate savings in each period

% Check dimensions of key variables
[a_rows, a_cols] = size(a);  % Get the number of rows (time periods) and columns (individuals)
assert(a_cols == 74, 'The number of individuals (columns in a) must be 74');
assert(a_rows == 201, 'The number of time periods (rows in a) must be 201');

% Check size of sv and hc (these should have 74 elements)
%assert(length(sv) == 74, 'sv must have 74 elements');
%assert(length(hc) == 74, 'hc must have 74 elements');

% Preallocate indkomst, opsparing, and savings rate
indkomst = zeros(74, a_rows);  % Now indkomst is [74, 201]
opsparing = zeros(74, a_rows);  % Now opsparing is [74, 201]
savings_rate = zeros(74, a_rows);  % Preallocate savings rate


% PLOT 1: Savings Rate for Selected Cohorts Over Time

% Specificer aldersgrupper
cohorts_to_plot = [10; 20; 30; 40];  % Selected age groups (e.g., j=10, j=20, etc.)

% Preallocate savings_rate and income for the selected cohorts
savings_rate = zeros(length(cohorts_to_plot), a_rows);
income_cohorts = zeros(length(cohorts_to_plot), a_rows);

% Define years corresponding to each period (1970 onwards)
years = 1970 + (0:a_rows-1);

% Calculate individual income and savings rate
for i = 1:length(cohorts_to_plot)
    j = cohorts_to_plot(i);  % Get the cohort index
    for t = 1:a_rows  
        if j > 1
            % Calculate profit income based on age condition
            if j <= 42
                profit_income = (1 - taup) * pi(t, j);  % Apply pi only if age <= 42
            else
                profit_income = 0;  % Set profit_income to zero if age > 42
            end
            
            % Apply bequest and pension income conditions
            bequest_income = (j == 25) * q(t);           % Apply q only to generation 25
            pension_income = (j >= 43) * dw(t);          % Apply dw only if age >= 43
            
            % Calculate total income
            indkomst(j, t) = r(t) * a(t, j)/sv(t,j)  + ...
                             (1 - tau(t)) * w(t) * hc(j) + ...
                             profit_income + bequest_income + pension_income;

            % Calculate savings for each individual
            opsparing(j, t) = indkomst(j, t) - c(t, j);

            % Calculate savings rate as opsparing / indkomst
            if indkomst(j, t) ~= 0  % Avoid division by zero
                savings_rate(i, t) = opsparing(j, t) / indkomst(j, t);  % Use i for row in savings_rate
            else
                savings_rate(i, t) = 0;  % Set savings rate to 0 if income is zero
            end

            % Store income size for cohort j
            income_cohorts(i, t) = indkomst(j, t);  % Use income indkomst(j, t) for each cohort
        end
    end
end

% Define cohort labels for the legend, converting age group index to actual age
cohort_labels = arrayfun(@(j) sprintf('%d-årige', 24 + j), cohorts_to_plot, 'UniformOutput', false);

% Create the plot
figure;
hold on;
for i = 1:length(cohorts_to_plot)
    plot(years, savings_rate(i, :)*100, 'LineWidth', 2, 'DisplayName', cohort_labels{i});
end
legend('show', 'FontSize', 15);

% Set the x-axis to display years from 1970 to 2100
%xlabel('År', 'FontSize', 15);
xlim([1970, 2100]);
ylabel('Pct.', 'FontSize', 15);
%title('Opsparingskvote for udvalgte aldersgrupper (1970-2100)', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axis ticks
grid on;

hold off;



% PLOT 2: Viser opsparingskvoten for forskellige aldre inden for samme år (kun aldersgruppe 1-42)

% Specify the periods you want to plot (1 (år 1970), 2 (år 1972), 55 (år 2024), and 101 (år 2070))
periods_to_plot = [1, 2, 55, 101];

% Preallocate storage for the savings rate at the specified periods, limited to age groups 1-42
savings_rate_periods = zeros(42, length(periods_to_plot));  

% Loop through the selected periods and age groups (1–42)
for t_idx = 1:length(periods_to_plot)
    t = periods_to_plot(t_idx);  % Get the specific period
    for j = 1:42  % Loop through age groups 1–42
        % Calculate profit income based on age condition
        profit_income = (1 - taup) * pi(t, j);  % Apply pi only if age <= 42
        
        % Apply bequest condition
        bequest_income = (j == 25) * q(t);  % Apply q only to generation 25
        
        % Calculate income for cohort j at period t
        asset_income = (a(t, j) > 0) * r(t) * a(t, j);  % Include only if assets are positive
        survival_income = (a(t, j) > 0) * r(t) * a(t, j) * (1 - sv(t, j)) / sv(t, j);  % Include only if assets are positive
        
        indkomst(j, t) = asset_income + survival_income + ...
                         (1 - tau(t)) * w(t) * hc(j) + ...
                         profit_income + bequest_income; 

        % Calculate savings for cohort j at period t
        opsparing(j, t) = indkomst(j, t) - c(t, j);
        
        % Calculate savings rate as opsparing / indkomst
        if indkomst(j, t) ~= 0  % Avoid division by zero
            savings_rate_periods(j, t_idx) = opsparing(j, t) / indkomst(j, t);
        else
            savings_rate_periods(j, t_idx) = 0;  % Set savings rate to 0 if income is zero
        end
    end
end

% Define the age mapping from 25 to 66 for the x-axis
age_groups_mapped = linspace(25, 66, 42);

% Create Plot 2, showing only ages 25–66 (corresponding to age groups 1–42)
figure;
plot(age_groups_mapped, savings_rate_periods(:, 1), 'r-', 'LineWidth', 1.5, 'DisplayName', '1970');
hold on;
plot(age_groups_mapped, savings_rate_periods(:, 2), 'k--', 'LineWidth', 1.5, 'DisplayName', '1972');
plot(age_groups_mapped, savings_rate_periods(:, 3), 'k', 'LineWidth', 1.5, 'DisplayName', '2024');
plot(age_groups_mapped, savings_rate_periods(:, 4), 'b--', 'LineWidth', 1.5, 'DisplayName', '2070');
hold off;

xlabel('Alder');
ylabel('Opsparingskvote');
title('PLOT 2: Opsparingskvote for udvalgte år for aldersgrupper 25–66');
legend('1970', '1972', '2024', '2070');
grid on;

% Set up a listener to dynamically format the y-axis tick labels with commas for Plot 2
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);


%PLOT 3 -  Individuel indkomst i udvalgte år

% Specify the periods you want to plot (1, 55, and 201)
periods_to_plot = [1, 55, 201];

% Preallocate storage for the income at the specified periods
income_periods = zeros(J, length(periods_to_plot)); 

for t_idx = 1:length(periods_to_plot)
    t = periods_to_plot(t_idx);  % Get the specific period
    for j = 1:J  % Loop through all cohorts
        % Calculate profit income based on age condition
        if j <= 42
            profit_income = (1 - taup) * pi(t, j);   % Apply pi only if age <= 42
        else
            profit_income = 0;  % Set profit_income to zero if age > 42
        end
        
        % Apply bequest and pension income conditions
        bequest_income = (j == 25) * q(t);           % Apply q only to generation 25
        pension_income = (j >= 43) * dw(t);          % Apply dw only if age >= 43

        % Calculate income for cohort j at period t
        income_periods(j, t_idx) = r(t) * a(t, j) / sv(t, j) + ...
                                   (1 - tau(t)) * w(t) * hc(j) + ...
                                   profit_income + bequest_income + pension_income;  %Prøv at lave om
    end
end

% Plot income across cohorts for the three periods
figure;
plot(1:J, income_periods(:, 1), 'r-', 'LineWidth', 1.5, 'DisplayName', '1970');  % Plot period 1
hold on;
plot(1:J, income_periods(:, 2), 'b--', 'LineWidth', 1.5, 'DisplayName', '2024');  % Plot period 55
plot(1:J, income_periods(:, 3), 'g-.', 'LineWidth', 1.5, 'DisplayName', '2170');  % Plot period 201
hold off;

% Add labels and title
xlabel('Cohort (Age Group)');
ylabel('Income');
title('PLOT 3: Income Across Cohorts selected periods');
legend('1970', '2024', '2170');
grid on;

% PLOT 4
% Plot of K (productive capital) and TK (total capital: productive + government debt)

T = 201;  % Number of periods

% Government debt as a fraction of capital
B = gov_debt_dyn .* K_dyn;  % Government debt

% Total capital (both productive and financial)
TK = K_dyn + B;  % Total capital: productive capital + government debt

% Create the plot
figure;
hold on;

% Plot productive capital (K)
plot(1:T, K_dyn, 'b-', 'LineWidth', 2, 'DisplayName', 'Productive Capital (K)');

% Plot total capital (TK)
plot(1:T, TK, 'r--', 'LineWidth', 2, 'DisplayName', 'Total Capital (K + B)');

hold off;

% Add labels, title, and legend
xlabel('Time (Periods)');
ylabel('Capital');
title('PLOT 4: Productive Capital (K) and Total Capital (K + B)');
legend('Location', 'Best');
grid on;

% Limit the x-axis to the first 100 periods if needed
xlim([1 201]);  % Optional: Set x-axis limits if necessary

% PLOT 5
% Plot of K/Y (Capital to Output ratio) and TK/Y (Total Capital to Output ratio)

T = 201;  % Number of periods

% Total Capital (TK = K + B)
TK = K_dyn + B;  % Total Capital (Productive + Financial)

% Calculate K/Y and TK/Y ratios
K_Y_ratio = K_dyn ./ Y_dyn;   % Capital to Output ratio
TK_Y_ratio = TK ./ Y_dyn;     % Total Capital to Output ratio

% Create the plot
figure;
hold on;

% Plot K/Y ratio
plot(1:T, K_Y_ratio, 'b-', 'LineWidth', 2, 'DisplayName', 'K/Y (Capital to Output Ratio)');

% Plot TK/Y ratio
plot(1:T, TK_Y_ratio, 'r--', 'LineWidth', 2, 'DisplayName', 'TK/Y (Total Capital to Output Ratio)');

hold off;

% Add labels, title, and legend
xlabel('Time (Periods)');
ylabel('Ratio');
title('PLOT 5: K/Y and TK/Y Ratios Over Time');
legend('Location', 'Best');
grid on;

% Limit the x-axis to the first 100 periods if needed
xlim([1 201]);  % Optional: Set x-axis limits if necessary

% PLOT 6 - AGG. OPSPARINGSKVOTE

% Total disposable income (Y_dyn - total taxes and depreciation of capital + overførsler)
total_disp_inc = Y_dyn - tau .* L_dyn .* w - taup .* PI_dyn - delta .* K_dyn + E + r.*B;

% Calculate the change in total capital (TK) over time
TK_diff = [diff(TK); 0]; % Use diff to compute the difference between consecutive TK values

% Calculate the aggregate savings rate as the change in total assets divided by disposable income
aggregate_savings_rate_1 = TK_diff ./ total_disp_inc; % Aggregate savings rate for each period

% An alternative method for calculating the aggregate savings rate
aggregate_savings_rate_2 = (total_disp_inc - C_dyn) ./ total_disp_inc;

% Plot both aggregate savings rates (aggregate_savings_rate_2 and aggregate_savings_rate_3) over time
figure;
hold on;  % Hold on to plot both lines in the same figure
plot(1:T, aggregate_savings_rate_1, 'm-', 'LineWidth', 2, 'DisplayName', 'Aggregate Savings Rate (ΔTK / Disposable Income)');
plot(1:T, aggregate_savings_rate_2, 'b', 'LineWidth', 2, 'DisplayName', 'Aggregate Savings Rate (Alternative Method)');
hold off;

% Add labels, title, and legend
xlabel('Time (Periods)');
ylabel('Aggregate Savings Rate');
title('PLOT 6: Aggregate Savings Rate Over Time');
legend('Location', 'Best');
grid on;


% PLOT 7: Aggregate Consumer Debt Over Time.
% Consumer Debt is the sums of all negative assets (debt)

%Transponer n
n = n';
% Initialize a vector to store total consumer debt for each period
total_consumer_debt = zeros(1, T);

% Loop over all periods to calculate aggregate consumer debt
for t = 1:T
    personal_debt = 0;  % Reset personal debt for each period
    for j = 1:J
        if a(t, j) < 0  % Check if the asset value is negative
            % Aggregate the debt weighted by population size and survival rate
            personal_debt = personal_debt + a(t, j) * n(j,t); %skal ikke dividere med sv(j,t) (åbenbart)
        end
    end
    % Store the absolute total consumer debt for this period
    total_consumer_debt(t) = -personal_debt;  % Debt is negative, so take the absolute value
end

% Calculate Consumer Debt to GDP Ratio (CDY) over time
Y_dyn_trans = Y_dyn';

CDY = total_consumer_debt ./ Y_dyn_trans;

% Plot the Consumer Debt to GDP Ratio (CDY) over time
figure;
plot(1:T, CDY, 'r-', 'LineWidth', 2, 'DisplayName', 'Consumer Debt to GDP Ratio');
xlabel('Time (Periods)');
ylabel('Debt to GDP Ratio');
title('PLOT 7: Aggregate Consumer Debt to GDP Ratio Over Time');
legend('Location', 'Best');
grid on;

%PLOT 8
%Laver plot over individernes aktiver fordelt efter alder inden for et
%bestemt år.

% PLOT 8.1: (uden indeks)

% Specify the periods you want to plot (1, 55, and 201)
periods_to_plot = [1, 55, 201];

% Preallocate storage for assets at the specified periods
assets_periods = zeros(J, length(periods_to_plot));  

% Loop through the periods and calculate the assets for each cohort in that period
for t_idx = 1:length(periods_to_plot)
    t = periods_to_plot(t_idx);  % Get the specific period
    for j = 1:J  % Loop through all cohorts (excluding last generation)
        % Store the individual assets for cohort j at period t
        assets_periods(j, t_idx) = a(t, j);  % Access assets directly from the `a` matrix
    end
end

% Plot assets across cohorts for the three selected periods
figure;
plot(1:J, assets_periods(:, 1), 'r-', 'LineWidth', 1.5, 'DisplayName', '1970');  % Plot period 1
hold on;
plot(1:J, assets_periods(:, 2), 'b--', 'LineWidth', 1.5, 'DisplayName', '2024');  % Plot period 55
plot(1:J, assets_periods(:, 3), 'g-.', 'LineWidth', 1.5, 'DisplayName', '2170');  % Plot period 201
hold off;

% Add labels and title for Plot 8
xlabel('Cohort (Age Group)');
ylabel('Assets');
title('PLOT 8:1 Assets Across Cohorts in Periods 1, 55, and 201');
legend('1970', '2024', '2170');
grid on;

% PLOT 8.2: Indexed Individual Assets Across Cohorts for Selected Periods with Last Age (74) Set to 1

% Specify the periods you want to plot (1, 55, and 101)
periods_to_plot = [1, 55, 101];

% Preallocate storage for indexed assets at the specified periods
indexed_assets_periods = zeros(J, length(periods_to_plot));  % Exclude last generation

% Loop through the periods and calculate the indexed assets for each cohort in that period
for t_idx = 1:length(periods_to_plot)
    t = periods_to_plot(t_idx);  % Get the specific period
    for j = 1:J  % Loop through all cohorts
        % Index the assets by dividing by the assets of the last age cohort (j=74) for each period
        if a(t, 74) == 0
            indexed_assets_periods(j, t_idx) = NaN;  % Handle case where base is zero to avoid division by zero
        else
            indexed_assets_periods(j, t_idx) = a(t, j) / a(t, 74);
        end
    end
end

% Define age mapping from 25 to 98 for the x-axis
age_groups_mapped = linspace(25, 98, J);

% Plot indexed assets across cohorts for the three selected periods
figure;
plot(age_groups_mapped, indexed_assets_periods(:, 1), 'Color', [0.6 0 0], 'LineWidth', 2, 'DisplayName', '1970');
hold on;
plot(age_groups_mapped, indexed_assets_periods(:, 2), 'Color', [0 0 0], 'LineWidth', 2, 'DisplayName', '2024');
plot(age_groups_mapped, indexed_assets_periods(:, 3), 'Color', [0 0 0.5], 'LineStyle', '-.', 'LineWidth', 2, 'DisplayName', '2070');
hold off;

xlabel('Alder', 'FontSize', 15);
ylabel('Indeks 98=1', 'FontSize', 15);
title('Aktiver efter alder i udvalgte år, indeks 98=1', 'FontSize', 15);
legend('1970', '2024', '2070', 'FontSize', 15);
xlim([25 98]);
set(gca, 'FontSize', 15);
grid on;

% Set up a listener to dynamically format the y-axis tick labels with commas for Plot 8.2
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);




% PLOT 9: Update for consumption ratio in specified periods
for t_idx = 1:length(periods_to_plot)
    t = periods_to_plot(t_idx);  % Get the specific period
    for j = 1:J  % Loop through all cohorts
        % Calculate profit income based on age condition
        if j <= 42
            profit_income = (1 - taup) * pi(t, j);   % Apply pi only if age <= 42
        else
            profit_income = 0;  % Set profit_income to zero if age > 42
        end
        
        % Apply bequest and pension income conditions
        bequest_income = (j == 25) * q(t);           % Apply q only to generation 25
        pension_income = (j >= 43) * dw(t);          % Apply dw only if age >= 43

        % Calculate income for cohort j at period t
        asset_income = (a(t, j) > 0) * r(t) * a(t, j);       % Include only if assets are positive
        survival_income = (a(t, j) > 0) * r(t) * a(t, j) * (1 - sv(t, j)) / sv(t, j);  % Include only if assets are positive

        indkomst(j, t) = asset_income + survival_income + ...
                         (1 - tau(t)) * w(t) * hc(j) + ...
                         profit_income + bequest_income + pension_income;  %FIXED
        
        % Calculate consumption ratio as consumption / income
        if indkomst(j, t) ~= 0  % Avoid division by zero
            consumption_ratio_periods(j, t_idx) = c(t, j) / indkomst(j, t);
        else
            consumption_ratio_periods(j, t_idx) = 0;  % Set consumption ratio to 0 if income is zero
        end
    end
end

% Plot consumption ratio across cohorts for the three selected periods
figure;
plot(1:J, consumption_ratio_periods(:, 1), 'r-', 'LineWidth', 1.5, 'DisplayName', '1970');  % Plot period 1
hold on;
plot(1:J, consumption_ratio_periods(:, 2), 'b--', 'LineWidth', 1.5, 'DisplayName', '2024');  % Plot period 55
plot(1:J, consumption_ratio_periods(:, 3), 'g-.', 'LineWidth', 1.5, 'DisplayName', '2070');  % Plot period 201
hold off;

% Add labels and title for Plot 9
xlabel('Cohort (Age Group)');
ylabel('Consumption Ratio');
title('PLOT 9: Consumption Ratio Across Cohorts in selected periods');
legend('1970', '2024', '2070');
grid on;

% Function to format y-axis ticks with commas (must be at the end of the file)
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace decimals with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end