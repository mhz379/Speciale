% Laver plot over overlevelseskurverne

clear all 

% Load the data from the "su" sheet of the Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\FN dødelighed, USA 1950-2100.xlsx';
data = readtable(filename, 'Sheet', 2, 'VariableNamingRule', 'preserve');




% Extract the years and survival probabilities
years = data{:, 1}; % Assuming the first column contains years
ages = 0:100;       % Ages from 0 to 100 (columns B to CW)

% Find the rows corresponding to the selected years
year_1950 = data{years == 1950, 2:end}; % Overlevelsessandsynligheder for 1950
year_1970 = data{years == 1970, 2:end}; % Overlevelsessandsynligheder for 1970
year_2024 = data{years == 2024, 2:end}; % Overlevelsessandsynligheder for 2024
year_2050 = data{years == 2050, 2:end}; % Overlevelsessandsynligheder for 2050
year_2100 = data{years == 2100, 2:end}; % Overlevelsessandsynligheder for 2050

% Check and adjust vector lengths
year_1970 = year_1970(1:length(ages));
year_2024 = year_2024(1:length(ages));
year_2050 = year_2050(1:length(ages));
year_2100 = year_2100(1:length(ages));

% Create the plot
figure;
plot(ages, year_1970, 'Color', [0.5 0 0], 'LineWidth', 2); hold on;  % Dark red solid line for 1970
plot(ages, year_2024, 'k-', 'LineWidth', 2);                         % Black solid line for 2024
plot(ages, year_2050, 'Color', [0.5 0.5 0.5], 'LineWidth', 2);       % Gray solid line for 2050
plot(ages, year_2100, 'Color', [0.5 0.5 0.5], 'LineStyle', '--', 'LineWidth', 2); % Gray dashed line for 2100
hold off;


% Adding title and labels
title('Dødelighed i USA', 'FontSize', 15);
xlabel('Alder', 'FontSize', 15);
ylabel('Andel overlevende', 'FontSize', 15);

% Adding legend with font size set to 15
legend({'1970','2024', '2050', '2100'}, 'Location', 'Best', 'FontSize', 15);

% Enhancing the plot with grid off, limits, and customized y-axis labels
grid off;
xlim([0 100]); % Set x-axis limits for ages from 0 to 100
ylim([0.0 1]); % Y-axis limits based on the typical range for survival probabilities

% Customizing y-axis tick labels to use commas instead of decimal points
yticklabels = get(gca, 'YTickLabel');              % Get the current y-axis tick labels
yticklabels = strrep(yticklabels, '.', ',');       % Replace '.' with ','
set(gca, 'YTickLabel', yticklabels);               % Set the new y-axis tick labels

% Set font size for x and y axis tick labels
set(gca, 'FontSize', 15);
