% Laver plot over den forventede levetid

% Load the data from the first sheet ("Import") of the Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\life_expectancy.xlsx';
data = readtable(filename, 'Sheet', 'Import', 'VariableNamingRule', 'preserve');

% Extract the years and life expectancy for each country
years = data{:, 1}; % First column: years
Tyskland = data{:, 3};
Japan = data{:, 4};
USA = data{:, 2};
Verden = data{:, 5};

% Create the plot
figure;
plot(years, Japan, 'Color', [0.5 0 0], 'LineStyle', '-', 'LineWidth', 2); hold on; 
plot(years, Tyskland, 'Color', [0.5 0.5 0.5], 'LineStyle', '-', 'LineWidth', 2); 
plot(years, USA, 'k-', 'LineWidth', 2); 
hold off;

% Adding title and labels
title('Forventet levetid (1960-2100)', 'FontSize', 15);
%xlabel('Årstal', 'FontSize', 15);
ylabel('År', 'FontSize', 15);

% Adding legend with font size set to 15
legend({'Japan', 'Tyskland', 'USA'}, 'Location', 'Best', 'FontSize', 15);

% Set font size for x and y axis tick labels
set(gca, 'FontSize', 15);

% Enhancing the plot
grid off;
xlim([years(11), years(end)]); % Set x-axis limits based on the data

% Get the current y-axis ticks and labels
yticks = get(gca, 'YTick');
yticklabels = strrep(cellstr(num2str(yticks')), '.', ',');

% Apply the new y-axis labels with commas
set(gca, 'YTickLabel', yticklabels);
