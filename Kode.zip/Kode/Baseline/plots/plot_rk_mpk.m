%Laver plot over renten og mpk i modellen

% Define the number of periods and truncate data for the first 131 periods
T = 201;  % Total number of periods
periods_to_plot = 131;  % First 131 periods

% Rental rate of capital (rk)
rentk = Simulated_time_series.data(1:T, 343);

% Wage
wage = Simulated_time_series.data(1:T, 342);

% Inverse of the markup (price)
price = Simulated_time_series.data(1:T, 345);

% Marginal product of capital (MPK)
mpk = rentk ./ price;

% Marginal product of labor (MPL)
mpl = wage ./ price;

% Define years for the plot (1970 to 2100 for the first 131 periods)
years = 1970:1970 + periods_to_plot - 1;

% Truncate data to the first 131 periods
rentk_truncated = rentk(1:periods_to_plot);
mpk_truncated = mpk(1:periods_to_plot);
wage_truncated = wage(1:periods_to_plot);
mpl_truncated = mpl(1:periods_to_plot);
%Forhold mellem mpl og w
forhold = mpl_truncated ./ wage_truncated;

% Calculate accumulated change in percentage points since period 1 (1970)
rentk_accumulated = (rentk_truncated - rentk_truncated(1)) * 100;  % Accumulated change in pp
mpk_accumulated = (mpk_truncated - mpk_truncated(1)) * 100;        % Accumulated change in pp

% Plot 1: accumulated change in rentk vs. mpk
figure;
hold on;

% Plot accumulated change in rentk
plot(years, rentk_accumulated, 'k', 'LineWidth', 2, 'DisplayName', 'Ændring i renten');

% Plot accumulated change in mpk (dark red)
plot(years, mpk_accumulated, 'Color', [0.5 0 0], 'LineStyle', '--', 'LineWidth', 2, 'DisplayName', 'Ændring i MPK');

% Add labels, title, and legend
ylabel('Pct.-point', 'FontSize', 15);
title('Ændring i renten og MPK siden 1970', 'FontSize', 15);

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);

% Add legend and grid
legend('Location', 'best', 'FontSize', 15);
grid on;

% Limit x-axis to 1970-2100
xlim([1970, 2100]);

% Adjust tick label font size
set(gca, 'FontSize', 15);

hold off;

% PLOT 2: Wage vs. MPL
figure;
hold on;

% Plot wage

plot(years, forhold, 'k', 'LineWidth', 2, 'DisplayName', 'Forhold');
%plot(years, wage_truncated, 'k', 'LineWidth', 2, 'DisplayName', 'Lønsats');

% Plot MPL (dark red)
%plot(years, mpl_truncated, 'Color', [0.5 0 0], 'LineStyle', '--', 'LineWidth', 2, 'DisplayName', 'MPL');

% Add labels, title, and legend
ylabel('Ratio', 'FontSize', 15);
title('Forhold mellem MPL og lønsatsen (1970-2030)', 'FontSize', 15);

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);

% Add legend and grid
%legend('Location', 'best', 'FontSize', 15);
grid on;

% Limit x-axis to 1970-2070
xlim([1970, 2030]);

% Adjust tick label font size
set(gca, 'FontSize', 15);

hold off;



% Function to format y-axis ticks with commas
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.2f')), '.', ',');  % Replace points with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end

