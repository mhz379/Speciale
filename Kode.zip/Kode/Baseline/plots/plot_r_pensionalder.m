%Laver plot er renten ved forskellige pensionsaldre (uden rekalibrering)

% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('r_v2.mat'); % baseline
r_v2 = baseline.r_dyn * 100;

r_64_data = load('r_v2.13_2.mat'); % pensionsalder på 64 år (ikke rekalibreret)
r_64 = r_64_data.r_dyn * 100;

r_70_data = load('r_v2.15.mat'); % pensionsalder på 70 år (ikke rekalibreret)
r_70 = r_70_data.r_dyn * 100;

% Define the years for the plot (1970 to 2100)
years = 1970:2100;

% Calculate accumulated change in percentage points since 1970
r_v2_accumulated = r_v2(1:131) - r_v2(1); % Baseline accumulated change
r_64_accumulated = r_64(1:131) - r_64(1); % 64 år accumulated change
r_70_accumulated = r_70(1:131) - r_70(1); % 70 år accumulated change

% PLOT 1: Interest rates
figure;
hold on;

% Plot each interest rate scenario with specified colors and line styles
plot(years, r_v2(1:131), 'k-', 'LineWidth', 2, 'DisplayName', '67 år (baseline)'); % Solid black for Baseline
plot(years, r_64(1:131), 'Color', [0.5 0 0], 'LineStyle', '-.', 'LineWidth', 2, 'DisplayName', '64 år'); % Mørkerød dashed
plot(years, r_70(1:131), 'Color', [0 0 0.6], 'LineStyle', '--', 'LineWidth', 2, 'DisplayName', '70 år'); % Mørkeblå dashed

% Add legend, labels, and title
ylabel('Pct. p.a.', 'FontSize', 15);
xlim([1970 2100]);
grid on;

% Set font size for x-axis and y-axis tick labels
set(gca, 'FontSize', 15);

% Add a listener to dynamically format the y-axis tick labels with commas on resize
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));

% Initial call to format y-axis tick labels
format_y_ticks(gca);

legend('Location', 'best', 'FontSize', 15);
%title('Udvikling i r* ved forskellige pensionsaldre', 'FontSize', 15);

hold off;

% PLOT 2: Accumulated change in pp since 1970
figure;
hold on;

% Plot accumulated change for each interest rate scenario
plot(years, r_v2_accumulated, 'k-', 'LineWidth', 2, 'DisplayName', 'Baseline (Akk.)'); % Solid black
plot(years, r_64_accumulated, 'Color', [0.5 0 0], 'LineStyle', '--', 'LineWidth', 2, 'DisplayName', '64 år (Akk.)'); % Mørkerød dashed
plot(years, r_70_accumulated, 'Color', [0 0 0.6], 'LineStyle', '--', 'LineWidth', 2, 'DisplayName', '70 år (Akk.)'); % Mørkeblå dashed

% Add labels, legend, and grid
ylabel('Ændring i pct. point', 'FontSize', 15);
xlim([1970 2100]);
title('Akkumuleret ændring i rente siden 1970', 'FontSize', 15);
grid on;

% Set font size for x-axis and y-axis tick labels
set(gca, 'FontSize', 15);

legend('Location', 'best', 'FontSize', 15);

hold off;

% Function to format y-axis ticks with commas
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end
