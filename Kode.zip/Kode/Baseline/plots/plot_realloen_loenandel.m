% Laver plot over reallønnen og lønandelen fra BLS i separate figurer
clear all

% Indlæser data fra Excel-filen
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Lønandel og realløn.xlsx';  % Path to your Excel file
sheet_name = 'Import';  % Sheet name where the data is stored
data = readtable(filename, 'Sheet', sheet_name);  % Read the table from the specified sheet

% Ekstraherer datoer, realløn og lønandel
dates = datetime(data{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Assuming dates are in the first column
real_wage = data{:, 2};  % Assuming "realløn" is in the second column
ls = data{:, 4};  % Assuming "lønandel" is in the fourth column

% Ekstraherer årstal fra datoen
years = year(dates);

% Find indekseringsfaktor for 1970 realløn
index_1970 = real_wage(years == 1970);  % Finde værdien af reallønnen i 1970 (Q1 i 1970)
real_wage_indexed = (real_wage / index_1970(1)) * 100;  % Indekserer reallønnen til 1970 = 100

% Begrænser dataen til årstal fra 1948 og frem
start_year = 1948;
real_wage_indexed = real_wage_indexed(years >= start_year);
ls = ls(years >= start_year);
dates = dates(years >= start_year);

%% Figur 1: Realløn (indekseret til 1970 = 100) i mørkegrå
figure;
plot(dates, real_wage_indexed, 'LineWidth', 2, 'Color', [0.3, 0.3, 0.3], 'DisplayName', 'Reale timeløn');
title('Reale timeløn (1948-2024)', 'FontSize', 15);
ylabel('Indeks 1970=100', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes
grid on;

% Optional: Save the figure
% saveas(gcf, 'reallon_plot.png');

%% Figur 2: Lønandel i mørkegrå
figure;
plot(dates, ls, 'LineWidth', 2, 'Color', [0.3, 0.3, 0.3], 'DisplayName', 'Lønandel');
title('Lønandel, 1948-2024', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes
grid on;

% Optional: Save the figure
% saveas(gcf, 'lonandel_plot.png');
