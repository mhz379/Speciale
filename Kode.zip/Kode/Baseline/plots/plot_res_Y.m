%Laver plot over residualen mellem Y og de samlede udgifter, C, G og I.

% -------------------------------------------------------------------------
% Aggregate savings rate calculation and plot

delta = 0.1;

% Total Kapital (K)
K_dyn = Simulated_time_series.data(1:T, 352);

% Total Income (Y)
Y_dyn = Simulated_time_series.data(1:T, 348);

% Total Consumption (C)
C_dyn = Simulated_time_series.data(1:T, 351);

% Rental rate (rk)
rk = Simulated_time_series.data(1:T, 343);

% Government expenditure as fraction of Y
g = 0.1554;

% Government Expenditure (GE)
GE = g .* Y_dyn;  % Off. forbrug (uden overførsler og renteudgifter)
G = Simulated_time_series.data(1:T, 353); %Samlede off. udgifter

%K/Y-forhold
KY = K_dyn ./ Y_dyn;

%Statens underskud
gov_deficit_dyn=Simulated_time_series.data(1:T,354); %Statens underskud målt ift. indtægterne
GU = gov_deficit_dyn .* G; %Statens underskud

%Government Debt
gov_debt_dyn=Simulated_time_series.data(1:T,355); %Statsgæld ift. beholdning af kapital

B = gov_debt_dyn .* K_dyn; % Statsgæld

% Compute the difference in government debt (B) across periods
B_diff = B(2:T) - B(1:T-1);

% Pad B_diff with NaN at the beginning to match the length of other series
B_diff = [NaN; B_diff];

% Investments (I)
I = K_dyn(2:T) - (1 - delta) * K_dyn(1:T-1);  % Calculate investments from t=1 to t=T-1

% I in period 201 (steady state value):
I_201 = ss_2024(356);  % Given steady state value of investment in period 201 (row 356)

% Append the steady state value for period 200 to the investments array
I = [I; I_201];

% Private Savings (PS)
PS = Y_dyn - C_dyn - GE;

PSY = PS./Y_dyn;


% Ressourcebetingelsen, residual
res = Y_dyn - C_dyn - I - GE + 0*GU - 0*B_diff; %

% -------------------------------------------------------------------------
% Plot residualen
figure;
hold on;
plot(1:T, res, 'LineWidth', 2);
%plot(1:T, B_diff, 'LineWidth', 2)
xlabel('Time (Periods)');
ylabel('res');
legend('res')
title('res = Y - C - I - G');
grid on;

% Limit the x-axis to the first 100 periods
%xlim([1 100]);  % Set x-axis limits to 1 to 100 periods


% -------------------------------------------------------------------------
% Plot K/Y-forholdet
figure;
hold on;
plot(1:T, KY, 'LineWidth', 2);
xlabel('Time (Periods)');
ylabel('Ratio');
legend('KY')
title('KY');
grid on;