% Plot til at sammenligne renter for forskellige pensionsaldre
clear all

% Load each interest rate scenario from the .mat files and rename the variable
baseline = load('r_v2.mat'); %Baseline, pensionsalder på j=43 (67 år).
r_v2 = baseline.r_dyn*100;

j40 = load('r_v2.13.mat'); %pensionsalder på j=40 (64 år).
r_v2_13 = j40.r_dyn*100;



% Define the years for the plot (1970 to 2030)
years = 1970:2100;

% Create the plot
figure;
hold on;

% Plot each interest rate scenario with specified line width
plot(years, r_v2(1:131), 'k-', 'LineWidth', 2, 'DisplayName', '67 år (baseline)');
plot(years, r_v2_13(1:131), 'Color', [0.6 0 0], 'LineStyle', ':', 'LineWidth', 2, 'DisplayName', '64 år');  % Grey


% Add legend, labels, and title with specified font size
legend('Location', 'best', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct. p.a.', 'FontSize', 15);
xlim([1970 2100]);
title('r*: pensionsalder på hhv. 64 og 67 år (1970-2100)', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes
grid on;

% Adjust the y-axis to use commas instead of points for decimals
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply modified tick labels

hold off;
