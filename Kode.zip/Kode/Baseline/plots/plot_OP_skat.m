% Plot over opsparingskvoten og skatten
clear all

% Load data
op_data = load('aggregate_savingsrate.mat'); % Opsparingskvote
op = op_data.aggregate_savings_rate_2 * 100;

skat_data = load('tau.mat'); % Tax rate
skat = skat_data.tau;

% Define the years for the plot (1970 to 2030)
years = 1970:2030;

% Create the plot
figure;
hold on;


% Plot opsparingskvoten on the left y-axis
yyaxis left;
plot(years, op(1:61), 'k-', 'LineWidth', 2, 'DisplayName', 'Opsparingskvote (v. akse)');
ylabel('Pct.', 'FontSize', 15); % Label for left y-axis
ax = gca; % Get current axes
ax.YColor = 'k'; % Set left y-axis color to match the plot line (black)

% Plot skatten on the right y-axis
yyaxis right;
plot(years, skat(1:61) * 100, 'b-.', 'LineWidth', 2, 'DisplayName', 'Skat (h. akse)');
ylabel('Pct.', 'FontSize', 15); % Label for right y-axis
ax.YColor = 'b'; % Set right y-axis color to match the plot line (red)

% Add legend, labels, and title with specified font size
legend('Location', 'best', 'FontSize', 15);
%xlabel('År', 'FontSize', 15); % Add x-axis label
%title('Privat opsparingskvote og skattesats (1970-2030)', 'FontSize', 15); % Add title
set(gca, 'FontSize', 15);  % Set font size for axes
grid on;

hold off;
