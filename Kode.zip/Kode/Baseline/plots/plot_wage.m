%Laver plot over lønnen i modellen

% Clear workspace
clear all

% Load data
wage_data = load('wages_v2.mat'); % Load wages data (baseline)
wage = wage_data.wages_dyn * 100; % %Gang med 100

wage_data_2 = load('wages_v2.12.mat'); % Load wages data (gA = 0)
wage2 = wage_data_2.wages_dyn * 100; %Gang med 100

% Define the years for the plot (1970 to 2070)
years = 1970:2070; % 101 years (1970 to 2070 inclusive)

% Truncate the wage series to match the number of years
wage_truncated = wage(1:length(years)); % Use only the first 101 elements
wage_truncated_2 = wage2(1:length(years)); % Use only the first 101 elements


% Calculate the annual growth rate in percentages
growth_rate = [NaN; diff(wage_truncated) ./ wage_truncated(1:end-1) * 100]; % Growth rate in %
%growth_rate(1) = 2; % Set the growth rate for the first period to 2%

% Calculate the annual growth rate in percentages
growth_rate_2 = [NaN; diff(wage_truncated_2) ./ wage_truncated_2(1:end-1) * 100]; % Growth rate in %
%growth_rate_2(1) = 0; % Set the growth rate for the first period to 2%

% Plot 1: Development of the real wage level
figure;
hold on;

% Plot the real wage
plot(years, wage_truncated, 'k-', 'LineWidth', 2, 'DisplayName', 'Baseline');
plot(years, wage_truncated_2, 'k--', 'LineWidth', 2, 'DisplayName', 'Ingen produktivitetsvækst');

% Add labels, title, and legend
ylabel('Indeks 1970=100', 'FontSize', 15);
title('Realløn, indeks 1970=100 (1970-2070)', 'FontSize', 15);


% Add grid and legend
grid on;
legend('Location', 'best', 'FontSize', 15);

% Adjust tick label font size
set(gca, 'FontSize', 15);

hold off;

% Plot 2: Annual growth rate of the real wage
figure;
hold on;

% Plot the annual growth rate
plot(years, growth_rate, 'k-', 'LineWidth', 2, 'DisplayName', 'Baseline');
plot(years, growth_rate_2, 'k--', 'LineWidth', 2, 'DisplayName', 'Ingen produktivitetsvækst');

% Add labels, title, and legend
ylabel('Pct.', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
title('Reallønsvækst i pct. p.a. (1970-2070)', 'FontSize', 15);

% Set up a listener to dynamically format the y-axis tick labels with commas
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);

% Add grid and legend
grid on;
legend('Location', 'best', 'FontSize', 15);

% Adjust tick label font size
set(gca, 'FontSize', 15);

hold off;



% Function to format y-axis ticks with commas
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end

