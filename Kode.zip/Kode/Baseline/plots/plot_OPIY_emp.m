% Laver plot over den empiriske opsparings- og investeringskvote.

%PLOT 1: Opsparingskvote i udvalgte OECD-lande
% Load savings rate data from the Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Privat_opsparingskvote_flere lande.xlsx';  % Path to your Excel file
sheet_name = 'Import';  % Sheet name where the data is stored
data = readtable(filename, 'Sheet', sheet_name);  % Read the table from the specified sheet

% Extract data columns
dates = datetime(data{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Convert the first column to datetime
savings_canada = data{:, 2};  % Savings rate for Canada
savings_japan = data{:, 3};   % Savings rate for Japan
savings_euro_area = data{:, 4};  % Savings rate for Euro Area
savings_us = data{:, 5};      % Savings rate for United States

% Plot savings rates for each country
figure;
hold on;
plot(dates, savings_japan, 'LineWidth', 2, 'Color', [0.5 0 0], 'DisplayName', 'Japan');        % Dark red line
plot(dates, savings_us, 'LineWidth', 2, 'Color', [0 0 0], 'DisplayName', 'USA');    % Black line
plot(dates, savings_canada, '--', 'LineWidth', 2, 'Color', [0.5 0.5 0.5], 'DisplayName', 'Canada');  % Grey dashed
plot(dates, savings_euro_area, '--', 'LineWidth', 2, 'Color', [0 0 0.5], 'DisplayName', 'Eurozonen'); % Dark blue dashed
hold off;

% Add labels, title, and legend
%xlabel('År', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);
title('Privat opsparingskvote (1970-2025)', 'FontSize', 15);
legend('Location', 'best', 'FontSize', 15);
grid on;

% Set font size for x- and y-axis tick labels
ax = gca;
ax.XAxis.FontSize = 15;
ax.YAxis.FontSize = 15;

% Optional: Limit x-axis range
xlim([datetime(1970, 1, 1) datetime(2025, 1, 1)]);

%PLOT 2: Bruttoinvesteringer ift. BNP
% Load savings rate data from the Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Bruttoinvesteringer_flere lande.xlsx';  % Path to your Excel file
sheet_name = 'Import';  % Sheet name where the data is stored
data = readtable(filename, 'Sheet', sheet_name);  % Read the table from the specified sheet

% Extract data columns
dates = datetime(data{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Convert the first column to datetime. Går fra 1970-2023.
IY_USA = data{:, 2}*100;      % I/Y USA
IY_Canada = data{:, 3}*100;   % I/Y Canada
IY_Japan = data{:, 4}*100;    % I/Y Japan
IY_Tyskland = data{:, 5}*100; % I/Y Tyskland
IY_Frankrig = data{:,6}*100;  % I/Y Frankrig
IY_UK = data{:,7}*100;        % I/Y UK
IY_Kina = data{:, 9}*100;     % I/Y Kina

% Plot I/Y for hvert land
figure;
hold on;
plot(dates, IY_Kina, '-', 'LineWidth', 2, 'Color', [0.8 0.6 0], 'DisplayName', 'Kina');            % Dark yellow line
plot(dates, IY_Japan, '-', 'LineWidth', 2, 'Color', [0.5 0 0], 'DisplayName', 'Japan');             % Dark red line
plot(dates, IY_Tyskland, '--', 'LineWidth', 2, 'Color', [0 0 0.5], 'DisplayName', 'Tyskland');       % Dark blue dashed
plot(dates, IY_Frankrig, '--', 'LineWidth', 2, 'Color', [0 0.5 0], 'DisplayName', 'Frankrig');        % Green dashed
plot(dates, IY_UK, '-', 'LineWidth', 2, 'Color', [0.3 0.6 1], 'DisplayName', 'UK');                 % Light blue line
plot(dates, IY_Canada, '--', 'LineWidth', 2, 'Color', [0.5 0.5 0.5], 'DisplayName', 'Canada');      % Grey dashed
plot(dates, IY_USA, 'LineWidth', 2, 'Color', [0 0 0], 'DisplayName', 'USA');                        % Black line
hold off;

% Add labels, title, and legend
%xlabel('År', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);
title('Bruttoinvesteringer ift. BNP (1970-2023)', 'FontSize', 15);
legend('Location', 'best', 'FontSize', 15);
grid on;

% Set font size for x- and y-axis tick labels
ax = gca;
ax.XAxis.FontSize = 15;
ax.YAxis.FontSize = 15;

% Optional: Limit x-axis range
xlim([datetime(1970, 1, 1) datetime(2023, 1, 1)]);