% Laver plot over budgetunderskud og statsgælden i andre lande
clear all;

% Indlæser data fra Excel-filen
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\FN_ældrebyrder.xlsx';  % Path to your Excel file
sheet_name = 'Import'; 

% Load data
data = readtable(filename, 'Sheet', sheet_name);  

% Extract years and country data (exclude Japan)
years = data{:, 1};  % Extract years from the first column
countries = {'USA', 'Tyskland', 'Frankrig', 'UK', 'Japan', 'Vesten'}; 

USA = data{:,2};
Tyskland = data{:,3};
Japan = data{:,6};
Vesten = data{:,7};


% PLOT
figure;
hold on;

% Plot each country's deficit
plot(years, Japan, 'Linestyle', '-', 'LineWidth', 2, 'Color', [0.5 0.0 0.0], 'DisplayName', 'Japan'); % Dark red solid
plot(years, Tyskland, 'Linestyle', '-', 'LineWidth', 2, 'Color', [0.5 0.5 0.5], 'DisplayName', 'Tyskland'); % Dark blue solid
plot(years, Vesten, '--', 'LineWidth', 2, 'Color', [0.0 0.0 0.5], 'DisplayName', 'Vesten'); % Grey dashed
plot(years, USA, 'k', 'LineWidth', 2, 'DisplayName', 'USA');



% Add labels, legend, and title
ylabel('Pct.', 'FontSize', 15);
%title('70+-årige ift. 25-69-årige', 'FontSize', 15);
legend('Location', 'best', 'FontSize', 15);
grid on;

% Adjust tick label font size
set(gca, 'FontSize', 15);

hold off;