% Laver plot over USA's betalingsbalance og NIIP

% 1. Indlæser data fra Excel-filen
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\USA betalingsbalance.xlsx';  % Path to your Excel file

% Sheet name and data import for the current account
sheet_name_1 = 'Import_1';  % Sheet name where the data for the current account is stored
data_1 = readtable(filename, 'Sheet', sheet_name_1);  % Read the table from the specified sheet

% Sheet name and data import for the net international investment position (NIIP)
sheet_name_2 = 'Import_2';  % Sheet name where the NIIP data is stored
data_2 = readtable(filename, 'Sheet', sheet_name_2);  % Read the table from the specified sheet

% Ekstraherer datoer og betalingsbalance fra data_1 (1970-2023)
dates_1 = datetime(data_1{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Assuming dates are in the first column
current_account = data_1{:, 2} * 100;  % Assuming the current account data is in the second column, converted to percentages

% Ekstraherer datoer og NIIP fra data_2 (1980-2023)
dates_2 = datetime(data_2{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Assuming dates are in the first column
niip = data_2{:, 2} * 100;  % Assuming the NIIP data is in the second column, converted to percentages

% PLOT 1: Betalingsbalancen som andel af BNP (Current Account as % of GDP)
figure;
plot(dates_1, current_account, 'Color', [0.3, 0.3, 0.3], 'LineWidth', 2);  % Dark grey line, line width 2
ylabel('Pct.', 'FontSize', 15);
title('Betalingsbalance i pct. af BNP (1970-2023)', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for the plot
grid on;

% PLOT 2: NIIP som andel af BNP (Net International Investment Position as % of GDP)
figure;
plot(dates_2, niip, 'Color', [0.3, 0.3, 0.3], 'LineWidth', 2);  % Dark grey line, line width 2
ylabel('Pct.', 'FontSize', 15);
title('Nettoudlandsformue i pct. af BNP (1980-2023)', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for the plot
grid on;
