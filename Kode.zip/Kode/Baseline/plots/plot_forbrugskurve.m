% Laver plot over forbrugskurverne i modellen og sammenligner med empirien.

% Load the interpolated consumption data from the BLS (forbrugsprofil_BLS.mat)
load('BLS_data.mat');  % This loads the 'consumption_full' variable

% Step 1: Extract the data for year 1, 50, 100, and 200 from c_indiv_dyn
data_year_1 = c_indiv_dyn(1, :);    % Data for year 1
data_year_55 = c_indiv_dyn(55, :);  % Data for year 50 (year 2024)
data_year_101 = c_indiv_dyn(101, :);% Data for year 101
data_year_201 = c_indiv_dyn(201, :);% Data for year 201 (2170)

% Step 2: Define the age groups for c_indiv_dyn (map 1 to 74 as 25 to 98)
age_groups_dyn = linspace(25, 98, 74);  % Age mapping from 25 to 98

% Step 3: Index the interpolated BLS data and model data to 25=1

%PLOT 1
% Index all model data to 25 = 1 (i.e., the first value in each series)
data_year_1_indexed = data_year_1 / data_year_1(1);       % Index year 1 (1970)
data_year_55_indexed = data_year_55 / data_year_55(1);    % Index year 50 (2024)
data_year_101_indexed = data_year_101 / data_year_101(1); % Index year 101 (2070)
data_year_201_indexed = data_year_201 / data_year_201(1); % Index year 200 (2170)

% Index the interpolated BLS data to 25=1
rebased_BLS = consumption_full / consumption_full(1);  % Indexed BLS data

% Step 4: Create the first plot for indexed data (model and BLS)

figure;  % Create a new figure
hold on;  % To plot multiple curves on the same figure

% Plot the indexed series from c_indiv_dyn (74 generations)
plot(age_groups_dyn, data_year_1_indexed, 'Color', [0.6 0 0], 'LineWidth', 2, 'DisplayName', '1970');  % Dark red for 1970
plot(age_groups_dyn, data_year_55_indexed, 'Color', [0 0 0], 'LineWidth', 2, 'DisplayName', '2024');  % Black for 2024
plot(age_groups_dyn, data_year_101_indexed,'-.', 'Color', [0 0 0.6], 'LineWidth', 2, 'DisplayName', '2070');  % Green for 2070

% Add the indexed BLS consumption profile to the plot (only until age 74)
plot(age_groups_dyn(age_groups_dyn <= 74), rebased_BLS(age_groups_dyn <= 74), '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 2, 'DisplayName', 'Data (BLS)');  % Grey for BLS data

% Customize the plot for c_indiv_dyn
title('Forbrug efter alder i udvalgte år, indeks 25=1', 'FontSize', 15);
xlabel('Alder', 'FontSize', 15);
ylabel('Indeks 25=1', 'FontSize', 15);
xlim([25, 99]);
legend('show', 'FontSize', 15);  % Display the legend for the curves

% Set up a listener to dynamically format the y-axis tick labels with commas for Plot 1
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);

grid on;
hold off;

%PLOT 2
% Step 5: Extract the data from the c_indiv_egg matrix for the last row (152)
data_egg_1970 = c_indiv_egg(1, :);
data_egg_2019 = c_indiv_egg(50, :);
data_egg_2121 = c_indiv_egg(152, :);  % Data for year 152 from Eggertsson

% Step 6: Index the Eggertsson data to 25=1
data_egg_1970_indexed = data_egg_1970 / data_egg_1970(1);  % Indexed year 1 (Eggertsson 1970)
data_egg_2019_indexed = data_egg_2019 / data_egg_2019(1);  % Indexed year 50 (Eggertsson 2019)
data_egg_2121_indexed = data_egg_2121 / data_egg_2121(1);  % Indexed year 152 (Eggertsson 2121)

% Step 7: Create the second plot for indexed Eggertsson data

figure;  % Create a new figure for the second plot
hold on;  % To plot multiple curves on the same figure
age_groups_egg = linspace(25, 80, 56);  % Age mapping for Eggertsson model (56 generations)

% Plot the indexed series from c_indiv_egg (56 generations)
plot(age_groups_egg, data_egg_1970_indexed, 'LineWidth', 2, 'DisplayName', 'År 1970 (Egg.)');  % Indexed curve for Eggertsson year 1970
plot(age_groups_egg, data_egg_2019_indexed, 'LineWidth', 2, 'DisplayName', 'År 2019 (Egg.)');  % Indexed curve for Eggertsson year 2019
plot(age_groups_egg, data_egg_2121_indexed, 'LineWidth', 2, 'DisplayName', 'År 2121 (Egg.)');  % Indexed curve for Eggertsson year 2121
plot(age_groups_dyn(age_groups_dyn <= 74), rebased_BLS(age_groups_dyn <= 74), '--', 'LineWidth', 2, 'DisplayName', 'Interpolated BLS (Indexed)'); 

% Customize the plot for c_indiv_egg
title('Indexed Consumption by Age (Eggertsson Model)', 'FontSize', 15);
xlabel('Age', 'FontSize', 15);
ylabel('Indexed Consumption (25 = 1)', 'FontSize', 15);
legend show;  % Display the legend for the curves

% Set up a listener to dynamically format the y-axis tick labels with commas for Plot 2
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);

grid on;
hold off;

%PLOT 3
% Step 8: Extract and plot the consumption profiles for multiple cohorts

% The cohort born in year 1 (1970), year 2000, year 2050, and year 2100
cohort_1970 = diag(c_indiv_dyn(1:74, 1:74));  % Born in year 1 (1970)
cohort_2000 = diag(c_indiv_dyn(31:104, 1:74));  % Born in year 2000
cohort_2050 = diag(c_indiv_dyn(81:154, 1:74));  % Born in year 2050
cohort_2100 = diag(c_indiv_dyn(131:200, 1:70)); % Born in year 2100 (assuming 200 years max)

% Define the age range for each cohort (age 25 to 98)
age_range_cohort = 25:98;

% Create the plot for all cohorts
figure;
hold on;
plot(age_range_cohort, cohort_1970, 'LineWidth', 2, 'DisplayName', 'Cohort 1970');
plot(age_range_cohort, cohort_2000, 'LineWidth', 2, 'DisplayName', 'Cohort 2000');
plot(age_range_cohort, cohort_2050, 'LineWidth', 2, 'DisplayName', 'Cohort 2050');
plot(age_range_cohort(1:70), cohort_2100, 'LineWidth', 2, 'DisplayName', 'Cohort 2100'); % 2100 cohort limited to 70 years

% Customize the plot
title('Consumption Profiles for Cohorts Born in 1970, 2000, 2050, and 2100', 'FontSize', 15);
xlabel('Age', 'FontSize', 15);
ylabel('Consumption', 'FontSize', 15);
legend('show', 'FontSize', 15);

% Set up a listener to dynamically format the y-axis tick labels with commas for Plot 3
addlistener(gcf, 'SizeChanged', @(src, event) format_y_ticks(gca));
% Apply initial formatting
format_y_ticks(gca);

grid on;
hold off;

% Function to format y-axis ticks with commas (must be at the end of the file)
function format_y_ticks(ax)
   yticks = get(ax, 'YTick');  % Get current y-tick values
   yticklabels = strrep(cellstr(num2str(yticks', '%.1f')), '.', ',');  % Replace points with commas
   set(ax, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply formatted tick labels
end
