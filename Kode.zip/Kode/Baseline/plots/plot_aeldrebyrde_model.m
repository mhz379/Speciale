%Laver plot over ældrebyrden i modellen og sammenligner med data.

% Assuming pop_indiv_dyn is a 200x74 matrix representing 200 years and 74 generations

%PLOT 1
% Step 1: Define the generations for dependent and working-age populations (change to 43:74 and 1:42)
dependent_generations = 43:74;  % Dependent population (generation 43 to 74)
working_generations = 1:42;     % Working-age population (generation 1 to 42)

% Step 2: Calculate the total population in each group for each year
dependent_population = sum(pop_indiv_dyn(:, dependent_generations), 2); % Summing from generation 43 to 74
working_population = sum(pop_indiv_dyn(:, working_generations), 2);     % Summing from generation 1 to 42

% Step 3: Compute the dependency ratio for each year
dependency_ratio_model = dependent_population ./ working_population * 100;

% Step 4: Adjust the model years to match 1970 to 2100 (assuming year 1 in the model is 1970)
years_model = 1970:2170;  % Assuming the model starts in 1970, spanning 200 years
valid_years_model = years_model >= 1970 & years_model <= 2100;  % Restrict to 1970 to 2100
dependency_ratio_model = dependency_ratio_model(valid_years_model);  % Keep only these years
years_model_1 = years_model(valid_years_model);  % Keep only these years

% Step 5: Load and process the empirical data
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Ældrebyrde USA 1950-2100.xlsx';
filename2 = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Aldersfordeling_USA.xlsx';
data = readtable(filename, 'Sheet', 'Import', 'ReadVariableNames', false); % Load without headers
data2 = readtable(filename2, 'Sheet', 'Figur', 'ReadVariableNames', false); % Load second file without headers

% Step 6: Extract the years and dependency ratios from the empirical data
% For medium fertility: rows 21 to 151 (1970 to 2100), and use the second column for the medium fertility series
empirical_years = data{21:151, 1};  % Extract years from 1970 to 2100 (row 21 corresponds to 1970)
age_dependency_medium = data{21:151, 2};  % Medium fertility series from column 2

% For low fertility: rows 75 to 151 (2024 to 2100), and use the third column for the low fertility series
empirical_years_low = data{75:151, 1};  % Extract years from 2024 to 2100 (row 75 corresponds to 2024)
age_dependency_low = data{75:151, 3};   % Low fertility series from column 3


% Step 7: Extract the data for "67+-årige/26-66-årige" from the third dataset
dependency_ratio_third_series = 100*data2{1:end, 2};  % Extract column C (3rd column), rows 3 to 133 (1970 to 2100)
years_third_series = (1970:2100)';  % Years corresponding to the third series

% Step 8: Create the plot and compare the model and empirical data
figure;
hold on;  % To plot multiple series on the same figure
% Plot the model's dependency ratio (black solid line)
plot(years_model_1, dependency_ratio_model, 'LineWidth', 2, 'Color', 'k', 'DisplayName', 'Model');

% Plot the empirical medium fertility series from 1970 (solid dark red line)
plot(empirical_years, age_dependency_medium, 'LineWidth', 2, 'Color', [0.55, 0, 0], 'DisplayName', '65+/20-64, FN (mellem)');

% Plot the empirical low fertility series starting from 2024 (dashed dark red line)
%plot(empirical_years_low, age_dependency_low, 'LineWidth', 2, 'Color', [0.55, 0, 0], 'LineStyle', '--', 'DisplayName', '65+/20-64, FN (lav)');

% Plot the third series "67+/26-66" (dashed dark blue line)
plot(years_third_series, dependency_ratio_third_series, 'LineWidth', 2, 'Color', [0, 0, 0.55], 'LineStyle', '--', 'DisplayName', '67+/25-66, CB');


% Step 9: Customize the plot
%title('Sammenligning af afhængighedsforhold (1970-2100)');
%xlabel('Year');
ylabel('Pct.', 'FontSize', 15);
legend('Location', 'Best', 'FontSize', 15);
grid on;
xlim([1970, 2100]); % Set x-axis limits based on the data

% Set font size for x and y axis tick labels
ax = gca;
ax.XAxis.FontSize = 15;
ax.YAxis.FontSize = 15;

hold off;

% Plot 2: Dependency ratio in the model (1970–2170)
figure;
hold on;

% Plot the model's dependency ratio over the full period (1970–2170)
plot(years_model, dependent_population ./ working_population * 100, 'LineWidth', 2, 'Color', 'k', 'DisplayName', 'Model');

% Customize the plot
title('Afhængighedsforhold i modellen (1970-2170)');
xlabel('Year');
ylabel('Pct.');
legend('Location', 'Best');
grid on;
xlim([1970, 2170]); % Set x-axis limits for the full period
hold off;