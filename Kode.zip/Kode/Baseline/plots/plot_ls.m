% Laver plot over lønandelen i modellen og sammenligner med data fra BLS

% 1. Indlæser data fra Excel-filen
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\Lønandel og realløn.xlsx';  % Path to your Excel file
sheet_name = 'Import';  % Sheet name where the data is stored
data = readtable(filename, 'Sheet', sheet_name);  % Read the table from the specified sheet

% Ekstraherer datoer og lønandel (quarterly data)
quarters = data{:, 1};  % Assuming dates are in the first column (quarters)
wage_share_quarterly = data{:, 4};  % Assuming "lønandel" is in the fourth column

% 2. Omregner kvartalsdata til årlige data (gennemsnit af 4 kvartaler per år)
years_unique = year(datetime(quarters, 'InputFormat', 'dd-MM-yyyy'));  % Convert to years
years = unique(years_unique);  % Unique years in the data
wage_share_yearly = zeros(length(years), 1);  % Preallocate for yearly wage share

for i = 1:length(years)
    year_mask = years_unique == years(i);  % Mask for selecting data from each year
    wage_share_yearly(i) = mean(wage_share_quarterly(year_mask));  % Average of 4 quarters per year
end

% 3. HP-filter for smoothing the empirical data over the entire period
lambda = 100;  % HP-filter's lambda value
[wage_share_trend, ~] = hpfilter(wage_share_yearly, lambda);  % Smoothed series

% 4. Begrænser til årene 1970-2024
year_start = 1970;
year_end = 2024;
year_mask = (years >= year_start) & (years <= year_end);  % Mask for selecting the relevant years
years_filtered = years(year_mask);  % Filtered years
wage_share_filtered = wage_share_yearly(year_mask);  % Filtered wage share data
wage_share_trend_filtered = wage_share_trend(year_mask);  % Filtered smoothed wage share data

% 5. Lønandel i modellen
T = length(wage_share_filtered);  % Make sure T matches the number of time periods in your data
L_dyn = Simulated_time_series.data(1:T, 350);
wages_dyn = Simulated_time_series.data(1:T, 342);
rentk_dyn = Simulated_time_series.data(1:T, 343);
K_dyn = Simulated_time_series.data(1:T, 352);
PI_dyn = Simulated_time_series.data(1:T, 347);

% Beregner lønandelen i modellen over tid som en tidsserie
LS_model = 100*((L_dyn .* wages_dyn) ./ ((L_dyn .* wages_dyn) + (rentk_dyn .* K_dyn) + PI_dyn));

% 6. Opretter plottet
figure;
hold on;

% Plotter de faktiske lønandelsdata (original empirical data) in dark red, dashed
plot(years_filtered, wage_share_filtered, 'LineWidth', 2, 'Color', [0.5 0 0], 'LineStyle', '--', 'DisplayName', 'Data'); % Dark Red Dashed

% % Plotter den udglattede lønandelsdata (smoothed empirical data) - commented out
% plot(years_filtered, wage_share_trend_filtered, '--', 'LineWidth', 2, 'Color', 'b', 'DisplayName', 'Data, udglattet');

% Plotter lønandelen fra modellen in black
plot(years_filtered, LS_model, 'LineWidth', 2, 'Color', [0 0 0], 'DisplayName', 'Model'); % Black

% Tilføjer titler og aksebeskrivelser med fontstørrelse 15
title('Lønandelen: model vs. data (1970-2024)', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Pct.', 'FontSize', 15);

% Tilpasning af legendens fontstørrelse
legend('show', 'FontSize', 15);

% Tilpasning af x- og y-akse tick-labels til fontstørrelse 15
ax = gca;
ax.XAxis.FontSize = 15;
ax.YAxis.FontSize = 15;

% Grid and x-axis limits
grid on;
xlim([1970, 2024]);

hold off;

% Optional: Save the plot
% saveas(gcf, 'loenandel_sammenligning.png');
