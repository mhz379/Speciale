%Laver plot over kapital per arbejder og vækstraten i arbejdsstyrken

% Define the number of periods and data
T = 201;  % Number of periods

% Total Capital (K)
K_dyn = Simulated_time_series.data(1:T, 352);

% Labor (L)
L_dyn = Simulated_time_series.data(1:T, 350);

% Population (N)
N_dyn = Simulated_time_series.data(1:T, 349);  % Assuming population is column 349

%Population of each generation (n{j})
pop_indiv_dyn=Simulated_time_series.data(1:T,1:74);

% Factor productivity (A)
A = Simulated_time_series.data(1:T, 404);

% Define years as a datetime array starting from 1970, with annual increments
years = datetime(1970, 1, 1) + calyears(0:T-1);

% -------------------------------------------------------------------------
% PLOT 1: Capital per worker and per capita (indexed to 1 in period 1)

% Capital per worker (K/L) indexed to 1
K_per_worker = (K_dyn ./ L_dyn) / (K_dyn(1) / L_dyn(1));

% Capital per capita (K/N) indexed to 1
K_per_capita = (K_dyn ./ N_dyn) / (K_dyn(1) / N_dyn(1));

% Plot Capital per worker and per capita (indexed)
figure;
plot(years, K_per_worker, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Capital per Worker');
hold on;
plot(years, K_per_capita, 'r--', 'LineWidth', 1.5, 'DisplayName', 'Capital per Capita');
hold off;

% Add labels and title
xlabel('Year');
ylabel('Indexed Capital');
title('Indexed Capital per Worker and per Capita (1970 = 1)');
legend('Capital per Worker', 'Capital per Capita');
grid on;
xlim([datetime(1970,1,1) datetime(2070,1,1)]);

% -------------------------------------------------------------------------
% PLOT 1.2: Growth Rate of Capital per Worker (1970-2030)

% Calculate the growth rate of capital per worker
K_per_worker_growth = (diff(K_per_worker(1:T)) ./ K_per_worker(1:T-1)) * 100;  % Growth rate in %

% Set the growth rate in the first period (1970) to g = 0.02 (or 2% in percentage terms)
K_per_worker_growth = [0.02 * 100; K_per_worker_growth];  % Indsæt 2%, da g=2% i ss i 1970.

% Plot growth rate of capital per worker
figure;
plot(years(1:T), K_per_worker_growth, 'Color', [0.3 0.3 0.3], 'LineWidth', 2); % Dark grey line
%xlabel('År', 'FontSize', 15);
ylabel('Pct. p.a.', 'FontSize', 15);
title('Vækstrate i kapital per arbejder (1970-2070)', 'FontSize', 15);
grid on;
xlim([datetime(1970,1,1) datetime(2070,1,1)]); % Adjusted x-axis limit to 2070


% Adjust the y-axis to use commas instead of points for decimals
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply modified tick labels

% Set font size for x- and y-axis tick labels
ax = gca;
ax.XAxis.FontSize = 15;
ax.YAxis.FontSize = 15;


% -------------------------------------------------------------------------
% PLOT 2: Capital per effective worker and per effective capita (indexed to 1)

% Capital per effective worker (K_tilde = K/(A*L)) indexed to 1
K_per_eff_worker = (K_dyn ./ (A .* L_dyn)) / (K_dyn(1) / (A(1) * L_dyn(1)));

% Capital per effective capita (K_tilde = K/(A*N)) indexed to 1
K_per_eff_capita = (K_dyn ./ (A .* N_dyn)) / (K_dyn(1) / (A(1) * N_dyn(1)));

% Plot Capital per effective worker and per effective capita (indexed)
figure;
plot(years, K_per_eff_worker, 'g-', 'LineWidth', 1.5, 'DisplayName', 'Capital per Effective Worker');
hold on;
%plot(years, K_per_eff_capita, 'm--', 'LineWidth', 1.5, 'DisplayName', 'Capital per Effective Capita');
hold off;

% Add labels and title
xlabel('Year');
ylabel('Indexed Effective Capital');
title('Indexed Capital per Effective Worker and per Effective Capita (1970 = 1)');
legend('Capital per Effective Worker');
xlim([datetime(1970,1,1) datetime(2070,1,1)]);
grid on;

% -------------------------------------------------------------------------
% PLOT 3: Capital per effective worker and Interest Rate

figure;
yyaxis left;  % Left y-axis for capital per effective worker
plot(years, K_per_eff_worker, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Capital per Effective Worker');
ylabel('Capital per Effective Worker');
xlabel('Year');
title('Capital per Effective Worker and Interest Rate (1970-2030)');
xlim([datetime(1970,1,1) datetime(2070,1,1)]);

yyaxis right;  % Right y-axis for interest rate
plot(years, r_dyn, 'r--', 'LineWidth', 1.5, 'DisplayName', 'Interest Rate');
ylabel('Interest Rate (%)');

% Add legend and grid
legend('Capital per Effective Worker', 'Interest Rate');
grid on;

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% PLOT 4: Growth Rate of Labor Force (L_dyn) and Growth Rate of Sum of Individuals aged 1-42

% Calculate growth rate of the labor force (L_dyn)
L_dyn_growth = (diff(L_dyn) ./ L_dyn(1:T-1)) * 100;  % Growth rate in %
initial_growth_rate = 0.013549868016229 * 100;  % Initial growth rate in percentage terms
L_dyn_growth = [initial_growth_rate; L_dyn_growth];  % Set initial growth rate for 1970

% Calculate sum of individuals aged 1 to 42 (ignoring ages 43 to 74)
sum_pop_indiv_age_1_to_42 = sum(pop_indiv_dyn(:, 1:42), 2);  % Sum across ages 1 to 42

% Calculate growth rate of sum of individuals aged 1 to 42
sum_pop_indiv_growth = (diff(sum_pop_indiv_age_1_to_42) ./ sum_pop_indiv_age_1_to_42(1:T-1)) * 100;  % Growth rate in %
sum_pop_indiv_growth = [initial_growth_rate; sum_pop_indiv_growth];  % Set initial growth rate for 1970

% Plot growth rate of labor force and growth rate of sum of individuals aged 1-42
figure;
hold on;

% Plot growth rate of labor force (L_dyn)
plot(years(1:T), L_dyn_growth, 'k-', 'LineWidth', 2, 'DisplayName', 'Arbejdsstyrken (L)');

% Plot growth rate of sum of individuals aged 1-42
plot(years(1:T), sum_pop_indiv_growth, 'Color', [0 0 0.6], 'LineStyle', '--', 'LineWidth', 2, 'DisplayName', 'Antal 25-66-årige');

% Add labels and title
ylabel('Pct. p.a.', 'FontSize', 15);
title('Vækstrate i arbejdsstyrken og antal 25-66-årige (1970-2070)');
xlim([datetime(1970,1,1) datetime(2070,1,1)]);

% Adjust y-axis to use commas instead of points for decimals
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply modified tick labels

% Add legend and grid
legend('Location', 'best');
grid on;

hold off;
