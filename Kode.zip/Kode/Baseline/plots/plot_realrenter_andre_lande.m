% Laver plot over realrenterne i forskellige lande
clear all
% Indlæser data fra Excel-filen
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\Ny rådata\renter andre lande.xlsx';  % Path to your Excel file
sheet_name = 'Import';  % Sheet name where the data is stored
data = readtable(filename, 'Sheet', sheet_name);  % Read the table from the specified sheet

% Ekstraherer datoer og konverterer til datetime-format
dates = datetime(data{:, 1}, 'InputFormat', 'dd-MM-yyyy');  % Date in the first column

% Ekstraherer rente- og inflationsdata for hvert land
% Japan
interest_rate_JP = data{:, 2};  % 1-årig rente, JP
inflation_JP = data{:, 3};      % Inflation, JP

% Tyskland
interest_rate_DE = data{:, 4};  % 1-årig rente, DE
inflation_DE = data{:, 5};      % Inflation, DE

% Canada
interest_rate_CA = data{:, 6};  % 2-årig rente, CA
inflation_CA = data{:, 7};      % Inflation, CA

% UK
interest_rate_UK = data{:, 8};  % 2-årig rente, UK
inflation_UK = data{:, 9};      % Inflation, UK

% Frankrig
interest_rate_FR = data{:, 10};  % 2-årig rente, FR
inflation_FR = data{:, 11};      % Inflation, FR

% USA
interest_rate_US = data{:, 12};  % 1-årig rente, US
inflation_US = data{:, 13};      % Inflation, US

% Beregn HP-filteret inflation (lambda=100) og realrenten for hvert land
lambda = 100;

% Japan: Ekskluder data før november 1975
exclude_date_JP = datetime(1975, 11, 1);
valid_JP = dates >= exclude_date_JP;  % Include only data from November 1975 and onwards
inflation_JP_valid = inflation_JP(valid_JP);  % Trim inflation data to match interest rate length
interest_rate_JP_valid = interest_rate_JP(valid_JP);
[smoothed_inflation_JP, ~] = hpfilter(inflation_JP_valid, lambda);
real_rate_JP = interest_rate_JP_valid - smoothed_inflation_JP;
dates_JP = dates(valid_JP);  % Matching dates for plotting

% Tyskland: Begræns inflationen til at matche længden af renten
inflation_DE_valid = inflation_DE(~isnan(interest_rate_DE));
[smoothed_inflation_DE, ~] = hpfilter(inflation_DE_valid, lambda);
interest_rate_DE_valid = interest_rate_DE(~isnan(interest_rate_DE));
real_rate_DE = interest_rate_DE_valid - smoothed_inflation_DE;

% Canada: Begræns inflationen til at matche længden af renten
inflation_CA_valid = inflation_CA(~isnan(interest_rate_CA));
[smoothed_inflation_CA, ~] = hpfilter(inflation_CA_valid, lambda);
interest_rate_CA_valid = interest_rate_CA(~isnan(interest_rate_CA));
real_rate_CA = interest_rate_CA_valid - smoothed_inflation_CA;

% UK: Begræns inflationen til at matche længden af renten
inflation_UK_valid = inflation_UK(~isnan(interest_rate_UK));
[smoothed_inflation_UK, ~] = hpfilter(inflation_UK_valid, lambda);
interest_rate_UK_valid = interest_rate_UK(~isnan(interest_rate_UK));
real_rate_UK = interest_rate_UK_valid - smoothed_inflation_UK;

% Frankrig: Begræns inflationen til at matche længden af renten
inflation_FR_valid = inflation_FR(~isnan(interest_rate_FR));
[smoothed_inflation_FR, ~] = hpfilter(inflation_FR_valid, lambda);
interest_rate_FR_valid = interest_rate_FR(~isnan(interest_rate_FR));
real_rate_FR = interest_rate_FR_valid - smoothed_inflation_FR;

% USA: Begræns inflationen til at matche længden af renten
inflation_US_valid = inflation_US(~isnan(interest_rate_US));
[smoothed_inflation_US, ~] = hpfilter(inflation_US_valid, lambda);
interest_rate_US_valid = interest_rate_US(~isnan(interest_rate_US));
real_rate_US = interest_rate_US_valid - smoothed_inflation_US;

% Begrænser dataen til efter januar 1990
start_date = datetime(1990, 1, 1);  % Start in January 1990
valid_dates_JP = dates_JP >= start_date;  % Japan
valid_dates_DE = dates >= start_date & ~isnan(interest_rate_DE);  % Germany
valid_dates_CA = dates >= start_date & ~isnan(interest_rate_CA);  % Canada
valid_dates_UK = dates >= start_date & ~isnan(interest_rate_UK);  % UK
valid_dates_FR = dates >= start_date & ~isnan(interest_rate_FR);  % France
valid_dates_US = dates >= start_date & ~isnan(interest_rate_US);  % USA

% Plotter realrenten for hvert land
figure;
hold on;

% Plot for Japan (starts from November 1975 but displayed from 1990)
plot(dates_JP(valid_dates_JP), real_rate_JP(valid_dates_JP), 'LineWidth', 2, 'Color', [0.55, 0, 0], 'DisplayName', 'Japan');

% Plot for Tyskland (Germany)
plot(dates(valid_dates_DE), real_rate_DE(valid_dates_DE), 'LineWidth', 2, 'Color', 'g', 'DisplayName', 'Tyskland');

% Plot for Canada
plot(dates(valid_dates_CA), real_rate_CA(valid_dates_CA), 'LineWidth', 2, 'Linestyle', '--', 'Color', 'm', 'DisplayName', 'Canada');

% Plot for UK
plot(dates(valid_dates_UK), real_rate_UK(valid_dates_UK), 'LineWidth', 2, ...
    'Linestyle', '-', 'Color', [0.2, 0.6, 1], 'DisplayName', 'UK'); % Neon light blue color


% Plot for Frankrig (France)
plot(dates(valid_dates_FR), real_rate_FR(valid_dates_FR), 'LineWidth', 2, 'Linestyle', '--', 'Color', [0.3, 0.3, 0.3], 'DisplayName', 'Frankrig');

% Plot for USA
plot(dates(valid_dates_US), real_rate_US(valid_dates_US), 'LineWidth', 2, 'Color', 'k', 'DisplayName', 'USA');

% Tilføjer titler og aksebeskrivelser
%title('Realrenter i forskellige lande', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);  % Uncomment if you want to add x-axis label
ylabel('Pct. p.a.', 'FontSize', 15);
legend('show', 'FontSize', 15);
set(gca, 'FontSize', 15);  % Set font size for axes ticks and grid
grid on;

hold off;
