%Laver plot er fertilitetskvotienten (data og model).

% Load fertility data from Excel file
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Ny data\jr_tfr_ny.xlsx';
data = readtable(filename, 'Sheet', 'Til figur');

% Extract columns from the table
years = data{:, 1};     % Assuming column A contains the years
faktisk = data{:, 2};   % Column B contains actual fertility data
model = data{:, 3};     % Column C contains model fertility data

% Create the plot
figure;
hold on;

% Plot empirical data with transparency
plot(years, faktisk, '-', 'Color', [0.5, 0, 0, 0.5], 'LineWidth', 2, 'DisplayName', 'Data');

% Plot model fertility rate
plot(years, model, '--', 'Color', [0, 0, 0], 'LineWidth', 2, 'DisplayName', 'Model');

% Add legend, labels, and title with font size adjustments
% Set x-axis to start at 1945
xlim([1945 max(years)]);
legend('Location', 'best', 'FontSize', 15);
%xlabel('År', 'FontSize', 15);
ylabel('Børn pr. kvinde', 'FontSize', 15);
%title('Fertilitetskvotient', 'FontSize', 15);

% Adjust the y-axis to use commas instead of points for decimals
yticks = get(gca, 'YTick');  % Get current y-tick values
yticklabels = strrep(cellstr(num2str(yticks')), '.', ',');  % Replace points with commas
set(gca, 'YTickLabel', yticklabels, 'FontSize', 15);  % Apply modified tick labels

% Enable grid
grid on;

hold off;
