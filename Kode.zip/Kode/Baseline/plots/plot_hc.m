% Laver plot over humankapitalprofilen
clear all

% Indlæser data fra Excel-filen
filename = 'D:\Programmer\Dynare\6.0\matlab\kode\Speciale\Min kode\Baseline_v2\data\data_hc.xlsx';  % Include the .xlsx extension
data = readtable(filename);

% Ekstraherer humankapitalkolonnerne (hc1 til hc42)
hc = data{:, 1:42};  % Assuming hc1 to hc42 are the first 42 columns

% Definerer x-aksen (aldersgruppen fra 25 til 66)
x_values = 25:66;  % This corresponds to hc1 to hc42

% Opretter plottet
figure;
plot(x_values, hc, 'LineWidth', 2, 'Color', [0.3, 0.3, 0.3]);  % Plotter med mørkegrå farve og tykkere linje

% Tilføj titel og akseetiketter med fontstørrelse 15
%title('Humankapitalprofil', 'FontSize', 15);
xlabel('Alder', 'FontSize', 15);
ylabel('Indeks 25=1', 'FontSize', 15);

% Tilpasning af x-aksen
xticks(25:5:66);  % Viser ticks for hver 5. alder: 25, 30, 35, osv.
xlim([25, 66]);  % Begræns x-aksen til intervallet 25 til 66

% Tilpasning af y-aksen til at vise komma som decimaltegn
yt = yticks;  % Henter de aktuelle ticks på y-aksen
yticklabels(strrep(cellstr(num2str(yt', '%.1f')), '.', ','));  % Erstatter punktum med komma

% Indstil fontstørrelse for aksetiketter
set(gca, 'FontSize', 15);
grid on;

% Optional: Save the plot
%saveas(gcf, 'humankapitalprofil.png');
